# Deposit System Setup Guide

## Quick Start

### 1. Generate Master Mnemonic

```bash
# Generate a new 24-word mnemonic (IMPORTANT: Keep this secure!)
python -c "from bip_utils import Bip39MnemonicGenerator, Bip39WordsNum; print(Bip39MnemonicGenerator().FromWordsNumber(Bip39WordsNum.WORDS_NUM_24))"
```

**⚠️ CRITICAL: Store this mnemonic securely! Anyone with this can access all deposit addresses.**

### 2. Create Hot Wallet

```bash
# Generate a hot wallet for gas funding (keep minimal balance here)
python -c "from eth_account import Account; import secrets; acc = Account.create(); print(f'Address: {acc.address}'); print(f'Private Key: {acc.key.hex()}')"
```

### 3. Set Master Wallet Addresses

For each chain, create a secure master wallet where swept funds will be sent:
- ETH: Use MetaMask/Ledger
- BNB: Use Trust Wallet/Binance
- Base: Use Coinbase Wallet
- TRON: Use TronLink
- Solana: Use Phantom
- TON: Use Tonkeeper

### 4. Configure Environment Variables

Create a `.env` file:

```bash
# Master seed (24 words)
MASTER_MNEMONIC="word1 word2 word3 ... word24"

# Hot wallet for gas funding (keep max $100 here)
HOT_WALLET_PRIVATE_KEY="0xabcdef..."

# Master wallets (where deposits are swept to - use cold wallets!)
MASTER_WALLET_ETH="0x..."
MASTER_WALLET_BNB="0x..."
MASTER_WALLET_BASE="0x..."
MASTER_WALLET_TRON="T..."
MASTER_WALLET_SOLANA="..."
MASTER_WALLET_TON="..."

# Optional: Custom RPC endpoints
ETH_RPC="https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY"
BNB_RPC="https://bsc-dataseed.binance.org/"
BASE_RPC="https://mainnet.base.org"

# Optional: Deposit settings
MIN_DEPOSIT_USD=10.0
SCAN_INTERVAL=30
SWEEP_INTERVAL=60
```

### 5. Load Environment

```bash
# In your shell
export $(cat .env | xargs)

# Or add to bot startup
python -c "from dotenv import load_dotenv; load_dotenv()"
```

### 6. Test Configuration

```bash
# Run the test suite
python test_deposit_system.py

# Should show all services initialized successfully
```

### 7. Start Bot

```bash
python bot.py
```

## Security Best Practices

### Master Mnemonic Security

1. **Never store in code or git**
   - Use environment variables only
   - Consider using AWS Secrets Manager, HashiCorp Vault, or similar

2. **Backup securely**
   - Write on paper, store in safe
   - Use steel backup (fire/water resistant)
   - Split using Shamir's Secret Sharing

3. **Access control**
   - Minimize who knows the mnemonic
   - Use separate mnemonics for dev/prod

### Hot Wallet Management

1. **Minimal balance**
   - Keep only enough for gas funding (~$50-100)
   - Refill regularly, don't store large amounts

2. **Monitor transactions**
   - Alert on any unexpected outgoing transactions
   - Rotate private key periodically

3. **Separate from master**
   - Never use hot wallet as master wallet
   - Different private keys

### Master Wallet Security

1. **Use hardware wallets**
   - Ledger, Trezor for EVM chains
   - Hardware wallet for all chains when possible

2. **Multi-sig recommended**
   - Require multiple signatures for large transfers
   - Gnosis Safe for EVM chains

3. **Regular sweeps to cold storage**
   - Don't accumulate large amounts in master wallet
   - Sweep to offline cold storage regularly

## Monitoring

### Key Metrics

```python
# Add to your monitoring dashboard
metrics = {
    'deposits_detected_24h': 0,
    'deposits_confirmed_24h': 0,
    'deposits_swept_24h': 0,
    'total_value_deposited_24h': 0,
    'failed_sweeps_24h': 0,
    'hot_wallet_balance': 0,
    'master_wallet_balances': {}
}
```

### Alerts to Set Up

1. **Hot wallet low balance** (< $10)
2. **Failed sweep** (3+ consecutive failures)
3. **Unexpected transaction** (from hot/master wallet)
4. **Large deposit** (> $10,000)
5. **RPC endpoint down**
6. **Database errors**

### Log Monitoring

```bash
# Watch logs for issues
tail -f logs/bot_*.log | grep -E "ERROR|deposit|sweep"

# Check deposit stats
sqlite3 deposits.db "SELECT chain, status, COUNT(*), SUM(amount_usd) FROM deposits GROUP BY chain, status"
```

## Troubleshooting

### Deposits Not Detected

1. **Check RPC connectivity**
```bash
curl -X POST $ETH_RPC -H "Content-Type: application/json" -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}'
```

2. **Verify address generation**
```bash
python test_deposit_system.py
```

3. **Check logs**
```bash
grep "scan_all_addresses" logs/bot_*.log
```

### Sweeps Failing

1. **Check hot wallet balance**
```python
# In Python shell
from bot import EvmService
service = EvmService('ETH')
balance = await service.get_balance('YOUR_HOT_WALLET_ADDRESS')
print(f"Hot wallet balance: {balance} ETH")
```

2. **Check gas prices**
- High gas prices may prevent sweeps
- Adjust GAS_AMOUNTS in config

3. **Verify master wallet addresses**
```bash
echo $MASTER_WALLET_ETH
# Should be valid address
```

### Database Issues

1. **Check database integrity**
```bash
sqlite3 deposits.db "PRAGMA integrity_check"
```

2. **Backup database**
```bash
cp deposits.db deposits_backup_$(date +%Y%m%d).db
```

3. **Reset if corrupted**
```bash
rm deposits.db
python bot.py  # Will recreate
```

## Advanced Configuration

### Custom Token Support

Add to `TOKEN_CONTRACTS` in bot.py:

```python
TOKEN_CONTRACTS = {
    "ETH": {
        "USDT": {"address": "0xdAC17F958D2ee523a2206206994597C13D831ec7", "decimals": 6},
        "USDC": {"address": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", "decimals": 6},
        "DAI": {"address": "0x6B175474E89094C44Da98b954EedeAC495271d0F", "decimals": 18},
    }
}
```

### Custom RPC Endpoints

For better reliability and rate limits:

```python
RPC_ENDPOINTS = {
    "ETH": os.getenv("ETH_RPC", "https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY"),
    "BNB": os.getenv("BNB_RPC", "https://bsc-mainnet.nodereal.io/v1/YOUR_KEY"),
    # Add backup RPCs
    "ETH_BACKUP": "https://rpc.ankr.com/eth",
}
```

### Webhook-Based Monitoring

Instead of polling, use webhooks:

```python
# Example with Alchemy
async def setup_webhooks():
    import httpx
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "https://dashboard.alchemy.com/api/create-webhook",
            json={
                "network": "ETH_MAINNET",
                "webhook_type": "ADDRESS_ACTIVITY",
                "addresses": user_addresses,
                "webhook_url": "https://your-bot.com/webhook"
            }
        )
```

## Production Deployment

### Systemd Service

Create `/etc/systemd/system/casino-bot.service`:

```ini
[Unit]
Description=Casino Deposit Bot
After=network.target

[Service]
Type=simple
User=botuser
WorkingDirectory=/opt/casino-bot
Environment="MASTER_MNEMONIC=..."
EnvironmentFile=/opt/casino-bot/.env
ExecStart=/usr/bin/python3 /opt/casino-bot/bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable casino-bot
sudo systemctl start casino-bot
sudo systemctl status casino-bot
```

### Docker Deployment

Create `Dockerfile`:

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY bot.py .
COPY *.txt .

ENV PYTHONUNBUFFERED=1
CMD ["python", "bot.py"]
```

Run:
```bash
docker build -t casino-bot .
docker run -d --name casino-bot --env-file .env casino-bot
```

### Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: casino-bot
spec:
  replicas: 1
  selector:
    matchLabels:
      app: casino-bot
  template:
    metadata:
      labels:
        app: casino-bot
    spec:
      containers:
      - name: casino-bot
        image: casino-bot:latest
        envFrom:
        - secretRef:
            name: casino-bot-secrets
        volumeMounts:
        - name: data
          mountPath: /app/data
      volumes:
      - name: data
        persistentVolumeClaim:
          claimName: casino-bot-data
```

## Backup & Recovery

### Database Backup

```bash
# Automated backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
sqlite3 deposits.db ".backup /backups/deposits_${DATE}.db"
# Upload to S3
aws s3 cp /backups/deposits_${DATE}.db s3://your-bucket/backups/
```

### Recovery Procedure

1. **Stop the bot**
```bash
sudo systemctl stop casino-bot
```

2. **Restore database**
```bash
cp /backups/deposits_YYYYMMDD.db deposits.db
```

3. **Verify integrity**
```bash
sqlite3 deposits.db "SELECT COUNT(*) FROM deposits"
```

4. **Restart bot**
```bash
sudo systemctl start casino-bot
```

## Support

For issues:
1. Check logs in `logs/` directory
2. Run `python test_deposit_system.py`
3. Verify environment variables are set
4. Review DEPOSIT_SYSTEM.md for common issues

## License

Part of the Telegram Casino & Escrow Bot system.
