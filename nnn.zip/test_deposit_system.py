#!/usr/bin/env python3
"""
Test script for deposit system functionality
"""

import sys
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Import deposit system components
sys.path.insert(0, os.path.dirname(__file__))

def test_imports():
    """Test that all deposit system imports work"""
    print("Testing imports...")
    try:
        from bot import (
            DepositDatabase, HDWalletManager, EvmService, 
            TronService, SolanaService, TonService,
            BlockMonitor, AutoSweeper
        )
        print("✅ All imports successful")
        return True
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False

def test_database():
    """Test database initialization"""
    print("\nTesting database...")
    try:
        from bot import DepositDatabase
        db = DepositDatabase("test_deposits.db")
        print("✅ Database initialized")
        
        # Test user creation
        user = db.get_or_create_user(123456789)
        print(f"✅ Created test user with index {user['address_index']}")
        print(f"   ETH address: {user['eth_address']}")
        print(f"   BNB address: {user['bnb_address']}")
        print(f"   TRON address: {user['tron_address']}")
        print(f"   Solana address: {user['solana_address']}")
        print(f"   TON address: {user['ton_address']}")
        
        # Clean up test database
        os.remove("test_deposits.db")
        return True
    except Exception as e:
        print(f"❌ Database test error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_wallet_manager():
    """Test HD wallet generation"""
    print("\nTesting HD wallet manager...")
    try:
        from bot import HDWalletManager
        
        wallet_manager = HDWalletManager()
        
        # Test address generation for each chain
        chains = ['ETH', 'BNB', 'BASE', 'TRON', 'SOLANA', 'TON']
        for chain in chains:
            try:
                address = wallet_manager.generate_address(chain, 0)
                print(f"✅ {chain:8} address: {address}")
            except Exception as e:
                print(f"⚠️  {chain:8} error: {e}")
        
        return True
    except Exception as e:
        print(f"❌ Wallet manager test error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_services():
    """Test blockchain services initialization"""
    print("\nTesting blockchain services...")
    try:
        from bot import EvmService, TronService, SolanaService, TonService
        
        # Test EVM services
        for chain in ['ETH', 'BNB', 'BASE']:
            try:
                service = EvmService(chain)
                print(f"✅ {chain} service initialized (RPC: {service.rpc_url})")
            except Exception as e:
                print(f"⚠️  {chain} service error: {e}")
        
        # Test TRON service
        try:
            service = TronService()
            print(f"✅ TRON service initialized")
        except Exception as e:
            print(f"⚠️  TRON service error: {e}")
        
        # Test Solana service
        try:
            service = SolanaService()
            print(f"✅ Solana service initialized")
        except Exception as e:
            print(f"⚠️  Solana service error: {e}")
        
        # Test TON service
        try:
            service = TonService()
            print(f"✅ TON service initialized")
        except Exception as e:
            print(f"⚠️  TON service error: {e}")
        
        return True
    except Exception as e:
        print(f"❌ Services test error: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("DEPOSIT SYSTEM TEST SUITE")
    print("=" * 60)
    
    results = []
    
    results.append(("Imports", test_imports()))
    results.append(("Database", test_database()))
    results.append(("Wallet Manager", test_wallet_manager()))
    results.append(("Services", test_services()))
    
    print("\n" + "=" * 60)
    print("TEST RESULTS")
    print("=" * 60)
    
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name:20} {status}")
    
    all_passed = all(result[1] for result in results)
    
    if all_passed:
        print("\n✅ All tests passed!")
        return 0
    else:
        print("\n⚠️  Some tests failed. Check logs above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
