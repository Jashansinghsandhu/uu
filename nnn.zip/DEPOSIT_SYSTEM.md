# Crypto Deposit System

## Overview

This is a complete, production-ready cryptocurrency deposit system integrated into the Telegram bot. It supports 6 major blockchains with HD wallet generation, automatic sweeping, and gas station functionality.

## Supported Blockchains

1. **Ethereum (ETH)** - Native ETH, USDT, USDC
2. **BNB Chain (BNB)** - Native BNB, USDT, USDC
3. **Base** - Native ETH, USDC
4. **TRON (TRX)** - Native TRX, USDT
5. **Solana (SOL)** - Native SOL, USDT, USDC (SPL tokens)
6. **TON** - Native TON

## Features

### 🔐 HD Wallet System
- BIP44-compliant hierarchical deterministic wallets
- Unique deposit address for each user on each chain
- On-the-fly private key derivation (keys never stored)
- Master mnemonic seed for all addresses

### 💰 Automatic Deposit Detection
- Real-time blockchain monitoring every 30 seconds
- Detects both native tokens and stablecoins (USDT/USDC)
- Tracks confirmation counts per chain
- Automatic user balance crediting

### 🚀 Auto-Sweep Functionality
- Automatically sweeps confirmed deposits to master wallet
- Gas Station pattern for token deposits
  - Detects token deposits that need gas
  - Automatically funds gas from hot wallet
  - Sweeps tokens after gas arrives
- Configurable sweep intervals
- Retry logic for failed sweeps

### 📊 Database Management
- SQLite database for deposit tracking
- User address mapping
- Deposit history with full transaction details
- Status tracking (pending, confirmed, swept)

### 🎨 User Interface
- Simple `/deposit` command
- Select blockchain from menu
- Get unique deposit address with QR code
- View deposit history
- Check deposit status

## Architecture

```
┌─────────────────┐
│  User deposits  │
│   to unique     │
│    address      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Block Monitor   │◄─── Scans every 30s
│ - Detects TXs   │
│ - Tracks confs  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Database        │
│ - Add deposit   │
│ - Track status  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Auto Sweeper    │◄─── Runs every 60s
│ - Fund gas      │
│ - Sweep tokens  │
│ - Send to master│
└─────────────────┘
```

## Configuration

### Environment Variables

```bash
# Master mnemonic for HD wallet generation (REQUIRED)
MASTER_MNEMONIC="your twelve or twenty four word mnemonic"

# Hot wallet private key for gas funding (REQUIRED)
HOT_WALLET_PRIVATE_KEY="0x..."

# Master wallet addresses where deposits are swept to
MASTER_WALLET_ETH="0x..."
MASTER_WALLET_BNB="0x..."
MASTER_WALLET_BASE="0x..."
MASTER_WALLET_TRON="T..."
MASTER_WALLET_SOLANA="..."
MASTER_WALLET_TON="..."

# RPC endpoints (optional, defaults provided)
ETH_RPC="https://eth.llamarpc.com"
BNB_RPC="https://bsc-dataseed.binance.org/"
BASE_RPC="https://mainnet.base.org"
TRON_RPC="https://api.trongrid.io"
SOLANA_RPC="https://api.mainnet-beta.solana.com"
TON_RPC="https://toncenter.com/api/v2/jsonRPC"

# Deposit settings
MIN_DEPOSIT_USD=10.0
SCAN_INTERVAL=30  # seconds
SWEEP_INTERVAL=60 # seconds
```

### In bot.py

All configuration is at the top of the file after line 80:

```python
DEPOSIT_ENABLED = True
MASTER_MNEMONIC = os.getenv("MASTER_MNEMONIC", "...")
HOT_WALLET_PRIVATE_KEY = os.getenv("HOT_WALLET_PRIVATE_KEY", "0x...")
MASTER_WALLETS = {...}
RPC_ENDPOINTS = {...}
TOKEN_CONTRACTS = {...}
MIN_DEPOSIT_USD = 10.0
SCAN_INTERVAL = 30
CONFIRMATIONS = {...}
GAS_AMOUNTS = {...}
```

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set environment variables:
```bash
export MASTER_MNEMONIC="your mnemonic here"
export HOT_WALLET_PRIVATE_KEY="0x..."
export MASTER_WALLET_ETH="0x..."
# ... set other master wallets
```

3. Run the bot:
```bash
python bot.py
```

## Usage

### For Users

1. Send `/deposit` command to the bot
2. Select a blockchain (ETH, BNB, Base, TRON, Solana, or TON)
3. Receive unique deposit address with QR code
4. Send crypto to that address
5. Balance automatically credited after confirmations
6. Funds automatically swept to master wallet

### For Admins

Monitor the system:
- Check `deposits.db` for all deposits
- View logs for sweep transactions
- Monitor master wallet balances

## Database Schema

### user_addresses
```sql
- user_id (PK)
- telegram_id (UNIQUE)
- address_index
- eth_address
- bnb_address
- base_address
- tron_address
- solana_address
- ton_address
- created_at
```

### deposits
```sql
- id (PK)
- tx_hash (UNIQUE)
- user_id (FK)
- chain
- token
- amount
- amount_usd
- from_address
- to_address
- status (pending/confirmed/swept)
- confirmations
- block_number
- sweep_tx_hash
- created_at
- confirmed_at
- swept_at
```

## Security Considerations

### ✅ Best Practices Implemented

1. **HD Wallet Security**
   - Master mnemonic should be stored in secure environment variable
   - Private keys derived on-the-fly, never stored
   - Each user gets unique addresses

2. **Hot Wallet Management**
   - Separate hot wallet for gas funding only
   - Keep minimal balance in hot wallet
   - Regularly sweep master wallets to cold storage

3. **Gas Station Pattern**
   - Only funds exact gas amount needed
   - Prevents dust attacks
   - Automatic retry on failures

4. **Confirmation Requirements**
   - ETH: 12 confirmations
   - BNB: 15 confirmations
   - Base: 10 confirmations
   - TRON: 19 confirmations
   - Solana: 32 confirmations
   - TON: 5 confirmations

### ⚠️ Security Warnings

1. **Protect Master Mnemonic**
   - Never commit to git
   - Use secure key management (AWS KMS, HashiCorp Vault, etc.)
   - Backup securely offline

2. **Hot Wallet Risks**
   - Private key needed for gas funding
   - Keep minimal balance
   - Monitor for unauthorized transactions

3. **RPC Endpoints**
   - Use authenticated endpoints in production
   - Implement rate limiting
   - Have backup RPC providers

## Monitoring & Maintenance

### Logs

All operations are logged:
```
- Deposit detection
- Confirmation tracking
- Gas funding transactions
- Sweep transactions
- Errors and retries
```

### Health Checks

Monitor these metrics:
- Deposit detection rate
- Sweep success rate
- Gas funding balance
- Database size
- RPC endpoint status

### Common Issues

1. **Deposits not detected**
   - Check RPC endpoint connectivity
   - Verify blockchain is synced
   - Check scan interval setting

2. **Sweeps failing**
   - Verify hot wallet has gas
   - Check master wallet addresses
   - Review gas amount settings

3. **Database locked**
   - Ensure single bot instance
   - Check file permissions
   - Consider PostgreSQL for high volume

## Advanced Features

### Custom Token Support

Add new tokens to `TOKEN_CONTRACTS`:

```python
TOKEN_CONTRACTS = {
    "ETH": {
        "USDT": {"address": "0x...", "decimals": 6},
        "CUSTOM": {"address": "0x...", "decimals": 18}
    }
}
```

### Multiple Master Wallets

For security, you can:
- Use different master wallets per chain
- Rotate master wallets periodically
- Implement multi-sig wallets

### Webhook Support

Instead of polling, implement webhooks:
- Alchemy, Infura, QuickNode webhooks
- Real-time deposit notifications
- Lower RPC costs

## Testing

Run the test suite:
```bash
python test_deposit_system.py
```

Tests cover:
- Import verification
- Database initialization
- HD wallet generation
- Service initialization

## Support

For issues or questions:
- Check logs in `logs/` directory
- Review database in `deposits.db`
- Inspect bot state in `bot_state.json`

## License

Part of the Telegram Casino & Escrow Bot system.

## Changelog

### v1.0.0 (2024-02-10)
- Initial release
- Support for 6 blockchains
- HD wallet generation
- Auto-sweep functionality
- Gas station pattern
- QR code generation
- Deposit history UI
