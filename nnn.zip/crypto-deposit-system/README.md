# Crypto Deposit System

Enterprise-grade, multi-chain cryptocurrency deposit system with HD wallet support, automatic sweeping, and gas station functionality.

## Features

- ✅ **Multi-Chain Support**: Ethereum, BNB Chain, Base, TRON (partial), Solana (partial), TON (partial)
- ✅ **HD Wallet Architecture**: Single master seed generates all user addresses
- ✅ **Non-Custodial**: Private keys derived on-the-fly, never stored
- ✅ **Gas Station**: Automatic gas funding for token sweeps
- ✅ **Auto-Sweep**: Automatic fund sweeping to master cold wallet
- ✅ **Idempotent**: Redis-backed state management prevents double-crediting
- ✅ **Confirmation Tracking**: Configurable confirmation requirements per chain
- ✅ **Queue System**: BullMQ-based asynchronous sweep processing
- ✅ **Alert System**: Database-backed alerts for failures and errors
- ✅ **PostgreSQL**: Robust transaction and user management
- ✅ **TypeScript**: Type-safe, maintainable codebase

## Current Limitations

### Solana
- ⚠️ **SPL Token Support**: SPL token sweeping not yet implemented (requires @solana/spl-token)
- ✅ Native SOL transfers: Fully working

### TON
- ⚠️ **Limited Implementation**: Several TON methods are placeholders
  - Transaction sweeping incomplete (requires full wallet contract setup)
  - Jetton (TON token) support not implemented
  - Transaction queries simplified
- ✅ Address generation: Working
- ✅ Balance queries: Working

### TRON
- ✅ TRX and TRC20 (USDT): Fully working
- ✅ All functionality implemented

## Architecture

### Components

1. **BlockMonitor**: Scans blockchains for incoming deposits
2. **SweeperQueue**: Manages asynchronous sweep operations with gas funding
3. **CryptoService**: Abstract base class for blockchain interactions
4. **Chain Services**: 
   - `EvmService` - Ethereum, BNB Chain, Base
   - `TronService` - TRON blockchain
   - `SolanaService` - Solana blockchain
   - `TonService` - TON blockchain

### Workflow

```
1. User requests deposit address
   ↓
2. System derives unique address from master seed + user index
   ↓
3. User sends crypto to their unique address
   ↓
4. BlockMonitor detects incoming transaction
   ↓
5. System waits for required confirmations
   ↓
6. For tokens: Gas Station funds gas if needed
   ↓
7. Sweeper signs transaction to send funds to master wallet
   ↓
8. Funds secured in master cold wallet
```

## Installation

```bash
# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Generate Prisma client
npm run prisma:generate

# Run database migrations
npm run prisma:migrate

# Build TypeScript
npm run build
```

## Configuration

### Required Environment Variables

```bash
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/crypto_deposit"

# Master Wallet (CRITICAL)
MASTER_MNEMONIC="your twelve or twenty four word phrase"

# Hot Wallet (for gas funding)
HOT_WALLET_PRIVATE_KEY="your-private-key"

# Master Cold Wallets
MASTER_WALLET_ETH="0x..."
MASTER_WALLET_BNB="0x..."
MASTER_WALLET_BASE="0x..."
MASTER_WALLET_TRON="T..."
MASTER_WALLET_SOLANA="..."
MASTER_WALLET_TON="..."

# RPC Endpoints
RPC_ETH="https://eth-mainnet.g.alchemy.com/v2/YOUR-KEY"
RPC_BNB="https://bsc-dataseed1.binance.org"
# ... etc
```

## Usage

### Start the System

```bash
# Development
npm run dev

# Production
npm start
```

### Integration Example

```typescript
import { depositSystem } from './src/index';

// Start the system
await depositSystem.start();

// Get deposit address for user
const address = await depositSystem.getDepositAddress(
  123456789, // Telegram User ID
  'eth'      // Chain: eth, bsc, base, tron, solana, ton
);

console.log(`Deposit ETH to: ${address}`);

// Get deposit history
const history = await depositSystem.getDepositHistory(123456789);
console.log(history);
```

## HD Wallet Derivation Paths

- **EVM Chains** (ETH, BNB, BASE): `m/44'/60'/0'/0/{index}`
- **TRON**: `m/44'/195'/0'/0/{index}`
- **Solana**: `m/44'/501'/{index}'/0'`
- **TON**: `m/44'/607'/0'/0/{index}` (custom deterministic)

## Security

### Best Practices

1. **Never commit `.env` file** - Contains sensitive keys
2. **Encrypt master mnemonic** - Use `MNEMONIC_ENCRYPTION_KEY`
3. **Secure hot wallet** - Only keep minimum gas funding balance
4. **Monitor alerts** - Set up alert webhooks/emails
5. **Regular backups** - Backup PostgreSQL database
6. **Private deployment** - Never expose RPC endpoints
7. **Rate limiting** - Implement API rate limits

### Key Management

- Master mnemonic stored encrypted in environment variable
- Private keys derived in-memory only when needed for signing
- No private keys stored in database or logs
- Hot wallet separate from master cold wallet

## Gas Station Logic

For token deposits (USDT, etc.):

1. Detect token deposit
2. Check if deposit address has gas
3. If insufficient gas:
   - Calculate required gas amount
   - Send exact gas from hot wallet
   - Wait for gas funding confirmation
4. Sign token transfer to master wallet
5. Complete sweep

## Monitoring

### Database Tables

- `User` - User to address index mapping
- `Deposit` - All deposit transactions
- `SystemState` - Blockchain scanning state
- `SweepQueue` - Sweep job queue
- `Alert` - System alerts and notifications

### Logs

- Application logs: `logs/deposit-system.log`
- Error logs: `logs/error.log`
- Log levels: error, warn, info, debug

### Redis Keys

- `last_scanned_block:{chain}` - Last scanned block per chain
- BullMQ queues for sweep processing

## Testing

```bash
# Run tests
npm test

# Run linter
npm run lint
```

## Troubleshooting

### Common Issues

1. **Sweep failed**: Check hot wallet balance for gas
2. **Block scan error**: Verify RPC endpoint is accessible
3. **Database connection**: Check PostgreSQL connection string
4. **Redis connection**: Ensure Redis is running
5. **Insufficient confirmations**: Wait for required confirmations

### Debug Mode

```bash
LOG_LEVEL=debug npm run dev
```

## Performance

- Scans all chains every 30 seconds (configurable)
- Processes up to 5 sweeps concurrently
- Rate limited to 10 operations per second
- Supports thousands of users with single master seed

## Roadmap

- [ ] Complete SPL token support for Solana
- [ ] Complete TON wallet contract implementation
- [ ] Complete TON Jetton support
- [ ] Additional chains (Polygon, Avalanche, etc.)
- [ ] WebSocket support for real-time monitoring
- [ ] Admin dashboard UI
- [ ] Advanced analytics and reporting
- [ ] Multi-signature wallet support
- [ ] Webhook notifications
- [ ] REST API endpoints

## License

ISC

## Support

For issues and questions, please create an issue in the repository.
