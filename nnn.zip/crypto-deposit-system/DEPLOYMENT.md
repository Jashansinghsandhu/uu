# Deployment Guide - Crypto Deposit System

This guide walks you through deploying the new enterprise-grade crypto deposit system.

## Prerequisites

### System Requirements
- Node.js 18.x or higher
- PostgreSQL 14.x or higher
- Redis 6.x or higher
- 2GB+ RAM
- 10GB+ disk space

### Required Services
1. **PostgreSQL Database**: For storing users, deposits, and system state
2. **Redis**: For caching and queue management
3. **RPC Endpoints**: For each blockchain you want to support
4. **Block Explorer API Keys**: For efficient transaction monitoring

## Step 1: Infrastructure Setup

### Install PostgreSQL

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install postgresql postgresql-contrib

# Start PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database
sudo -u postgres psql
CREATE DATABASE crypto_deposit;
CREATE USER crypto_user WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE crypto_deposit TO crypto_user;
\q
```

### Install Redis

```bash
# Ubuntu/Debian
sudo apt install redis-server

# Start Redis
sudo systemctl start redis
sudo systemctl enable redis

# Test Redis
redis-cli ping
# Should return: PONG
```

## Step 2: Generate Master Wallet

⚠️ **CRITICAL**: The master mnemonic controls ALL user deposit addresses. Keep it EXTREMELY secure!

```bash
# Generate a new 24-word mnemonic (recommended for maximum security)
# You can use any BIP39 mnemonic generator

# Example using Node.js
node -e "const bip39 = require('bip39'); console.log(bip39.generateMnemonic(256));"

# Store this mnemonic in a SECURE location:
# - Hardware wallet
# - Encrypted vault
# - Offline storage
# - NEVER commit to git
# - NEVER share with anyone
```

## Step 3: Setup Hot Wallet

The hot wallet is used ONLY for funding gas. Keep minimal balance.

```bash
# Generate a separate wallet for gas funding
# This should have only enough ETH/BNB/TRX for gas funding
# Recommended: 0.1 ETH, 0.5 BNB, 1000 TRX

# Get private key from your wallet
# Store securely in environment variables
```

## Step 4: Configure Environment

```bash
cd crypto-deposit-system
cp .env.example .env

# Edit .env with your values
nano .env
```

### Critical Configuration

```bash
# Database (REQUIRED)
DATABASE_URL="postgresql://crypto_user:your_password@localhost:5432/crypto_deposit"

# Redis (REQUIRED)
REDIS_HOST="localhost"
REDIS_PORT=6379
REDIS_PASSWORD=""  # Set if Redis has password

# Master Mnemonic (CRITICAL - KEEP SECRET!)
MASTER_MNEMONIC="your twenty four word mnemonic phrase goes here in quotes"

# Hot Wallet (for gas funding only)
HOT_WALLET_PRIVATE_KEY="0x..."

# Master Cold Wallets (where ALL funds are swept)
MASTER_WALLET_ETH="0x..."
MASTER_WALLET_BNB="0x..."
MASTER_WALLET_BASE="0x..."
MASTER_WALLET_TRON="T..."
MASTER_WALLET_SOLANA="..."
MASTER_WALLET_TON="..."
```

### Get RPC Endpoints

**Ethereum:**
- Alchemy: https://alchemy.com/ (Recommended)
- Infura: https://infura.io/
- QuickNode: https://www.quicknode.com/

**BNB Chain:**
- Public: https://bsc-dataseed1.binance.org
- QuickNode: https://www.quicknode.com/

**Base:**
- Base RPC: https://mainnet.base.org
- Alchemy: https://alchemy.com/

**TRON:**
- TronGrid: https://www.trongrid.io/
- Free: https://api.trongrid.io

**Solana:**
- Public: https://api.mainnet-beta.solana.com
- Helius: https://helius.xyz/ (Recommended)

**TON:**
- TON Center: https://toncenter.com/api/v2/jsonRPC

### Get API Keys

1. **Etherscan**: https://etherscan.io/apis
2. **BSCScan**: https://bscscan.com/apis
3. **Basescan**: https://basescan.org/apis
4. **TronScan**: https://tronscan.org/
5. **Solscan**: https://solscan.io/
6. **TONScan**: https://tonscan.org/

## Step 5: Install Dependencies

```bash
cd crypto-deposit-system
npm install
```

## Step 6: Database Setup

```bash
# Generate Prisma client
npm run prisma:generate

# Run migrations
npm run prisma:migrate

# Verify database
npm run prisma:studio
# Opens a web UI to view your database
```

## Step 7: Test Configuration

Create a test script to verify everything is configured correctly:

```typescript
// test-config.ts
import { depositSystem } from './src/index';

async function test() {
  try {
    // Test address generation
    const ethAddress = await depositSystem.getDepositAddress(12345, 'eth');
    console.log('✅ ETH address generated:', ethAddress);
    
    const bnbAddress = await depositSystem.getDepositAddress(12345, 'bsc');
    console.log('✅ BNB address generated:', bnbAddress);
    
    // Verify same EVM address
    if (ethAddress === bnbAddress) {
      console.log('✅ Same EVM address across chains');
    }
    
    console.log('\n✅ All tests passed!');
  } catch (error) {
    console.error('❌ Test failed:', error);
  }
}

test();
```

Run the test:
```bash
npx ts-node test-config.ts
```

## Step 8: Build and Start

```bash
# Build TypeScript
npm run build

# Start in production
npm start

# Or in development with auto-reload
npm run dev
```

## Step 9: Monitor Logs

```bash
# View logs
tail -f logs/deposit-system.log

# View error logs
tail -f logs/error.log
```

## Step 10: Integration with Telegram Bot

Add to your bot code:

```python
# Python integration example
import requests

def get_deposit_address(telegram_user_id, chain):
    """Get deposit address from TypeScript service"""
    response = requests.post('http://localhost:3000/deposit-address', json={
        'telegramId': telegram_user_id,
        'chain': chain
    })
    return response.json()['address']

def get_deposit_history(telegram_user_id):
    """Get user's deposit history"""
    response = requests.get(f'http://localhost:3000/deposits/{telegram_user_id}')
    return response.json()
```

## Security Checklist

- [ ] Master mnemonic stored securely (NOT in .env file in production)
- [ ] Hot wallet has minimal balance (only for gas)
- [ ] Master cold wallets are in secure storage (hardware wallet recommended)
- [ ] PostgreSQL uses strong password
- [ ] Redis has password protection enabled
- [ ] Firewall configured to block external access to database/redis
- [ ] SSL/TLS enabled for RPC connections
- [ ] Environment variables encrypted at rest
- [ ] Logs don't contain sensitive data
- [ ] Regular backups of PostgreSQL database
- [ ] Monitoring and alerting configured

## Production Deployment

### Using PM2 (Recommended)

```bash
# Install PM2
npm install -g pm2

# Start application
pm2 start dist/index.js --name crypto-deposit-system

# Configure auto-restart
pm2 startup
pm2 save

# Monitor
pm2 monit

# View logs
pm2 logs crypto-deposit-system
```

### Using Docker

```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 3000

CMD ["npm", "start"]
```

```bash
# Build image
docker build -t crypto-deposit-system .

# Run container
docker run -d \
  --name crypto-deposit \
  -p 3000:3000 \
  --env-file .env \
  crypto-deposit-system
```

## Maintenance

### Database Backups

```bash
# Backup PostgreSQL
pg_dump -U crypto_user crypto_deposit > backup_$(date +%Y%m%d).sql

# Restore
psql -U crypto_user crypto_deposit < backup_20240210.sql
```

### Update Dependencies

```bash
# Check for updates
npm outdated

# Update (be careful with major versions)
npm update

# Rebuild
npm run build
```

### Monitor Hot Wallet Balance

Set up alerts when hot wallet balance is low:

```bash
# Check balances regularly
# Set up monitoring script
```

## Troubleshooting

### Issue: "Cannot connect to database"
```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Test connection
psql -U crypto_user -d crypto_deposit -h localhost
```

### Issue: "Redis connection failed"
```bash
# Check Redis is running
sudo systemctl status redis

# Test connection
redis-cli ping
```

### Issue: "RPC endpoint not responding"
```bash
# Test RPC endpoint
curl -X POST -H "Content-Type: application/json" \
  --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' \
  YOUR_RPC_ENDPOINT
```

### Issue: "Sweep failed"
```bash
# Check hot wallet balance
# Check gas prices
# View error logs
tail -f logs/error.log
```

## Support

For issues and questions:
- Check logs: `logs/deposit-system.log`
- Review alerts in database: `SELECT * FROM "Alert" WHERE resolved = false`
- Contact support with error details

## Next Steps

1. Set up monitoring and alerting
2. Configure backup schedules
3. Test with small amounts first
4. Gradually increase limits
5. Monitor performance and optimize as needed
