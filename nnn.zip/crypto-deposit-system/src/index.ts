import { PrismaClient } from '@prisma/client';
import { config } from './config';
import { logger } from './utils/logger';
import { SweeperQueue } from './services/SweeperQueue';
import { BlockMonitor } from './services/BlockMonitor';
import { EvmServiceFactory } from './services/EvmService';
import { TronService } from './services/TronService';
import { SolanaService } from './services/SolanaService';
import { TonService } from './services/TonService';

const prisma = new PrismaClient();

/**
 * Main Crypto Deposit System
 * Enterprise-grade multi-chain deposit processor
 */
class CryptoDepositSystem {
  private sweeperQueue: SweeperQueue;
  private blockMonitor: BlockMonitor;
  private isRunning: boolean = false;
  
  constructor() {
    this.sweeperQueue = new SweeperQueue();
    this.blockMonitor = new BlockMonitor(this.sweeperQueue);
  }
  
  /**
   * Start the deposit system
   */
  async start(): Promise<void> {
    if (this.isRunning) {
      logger.warn('Crypto Deposit System is already running');
      return;
    }
    
    try {
      logger.info('Starting Crypto Deposit System');
      logger.info(`Environment: ${config.NODE_ENV}`);
      logger.info(`Auto-sweep: ${config.ENABLE_AUTO_SWEEP}`);
      logger.info(`Gas station: ${config.ENABLE_GAS_STATION}`);
      
      // Verify database connection
      await prisma.$connect();
      logger.info('Database connected');
      
      // Start block monitoring
      await this.blockMonitor.start();
      logger.info('Block monitor started');
      
      this.isRunning = true;
      logger.info('✅ Crypto Deposit System is running');
      
      // Set up graceful shutdown
      this.setupGracefulShutdown();
    } catch (error) {
      logger.error(`Failed to start Crypto Deposit System: ${error}`);
      throw error;
    }
  }
  
  /**
   * Stop the deposit system
   */
  async stop(): Promise<void> {
    if (!this.isRunning) {
      return;
    }
    
    logger.info('Stopping Crypto Deposit System');
    
    try {
      await this.blockMonitor.stop();
      await this.sweeperQueue.close();
      await prisma.$disconnect();
      
      this.isRunning = false;
      logger.info('✅ Crypto Deposit System stopped gracefully');
    } catch (error) {
      logger.error(`Error during shutdown: ${error}`);
      throw error;
    }
  }
  
  /**
   * Setup graceful shutdown handlers
   */
  private setupGracefulShutdown(): void {
    const shutdown = async (signal: string) => {
      logger.info(`Received ${signal}, shutting down gracefully`);
      await this.stop();
      process.exit(0);
    };
    
    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
    
    process.on('unhandledRejection', (reason, promise) => {
      logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
    });
    
    process.on('uncaughtException', (error) => {
      logger.error('Uncaught Exception:', error);
      shutdown('uncaughtException');
    });
  }
  
  /**
   * Get deposit address for a user
   */
  async getDepositAddress(telegramId: number, chain: string): Promise<string> {
    try {
      // Find or create user
      let user = await prisma.user.findUnique({
        where: { telegramId: BigInt(telegramId) }
      });
      
      if (!user) {
        // Get next address index
        const maxIndex = await prisma.user.findFirst({
          orderBy: { addressIndex: 'desc' },
          select: { addressIndex: true }
        });
        
        const nextIndex = (maxIndex?.addressIndex || 0) + 1;
        
        // Create user
        user = await prisma.user.create({
          data: {
            telegramId: BigInt(telegramId),
            addressIndex: nextIndex
          }
        });
        
        logger.info(`Created new user ${telegramId} with address index ${nextIndex}`);
      }
      
      // Generate address for the specified chain
      const mnemonic = config.getMasterMnemonic();
      let service;
      
      switch (chain) {
        case 'eth':
          service = EvmServiceFactory.createEthereumService(
            mnemonic,
            config.RPC_ENDPOINTS.ETH,
            config.MASTER_WALLETS.ETH
          );
          break;
        case 'bsc':
          service = EvmServiceFactory.createBnbService(
            mnemonic,
            config.RPC_ENDPOINTS.BNB,
            config.MASTER_WALLETS.BNB
          );
          break;
        case 'base':
          service = EvmServiceFactory.createBaseService(
            mnemonic,
            config.RPC_ENDPOINTS.BASE,
            config.MASTER_WALLETS.BASE
          );
          break;
        case 'tron':
          service = new TronService(
            mnemonic,
            config.RPC_ENDPOINTS.TRON,
            config.MASTER_WALLETS.TRON
          );
          break;
        case 'solana':
          service = new SolanaService(
            mnemonic,
            config.RPC_ENDPOINTS.SOLANA,
            config.MASTER_WALLETS.SOLANA
          );
          break;
        case 'ton':
          service = new TonService(
            mnemonic,
            config.RPC_ENDPOINTS.TON,
            config.MASTER_WALLETS.TON
          );
          break;
        default:
          throw new Error(`Unsupported chain: ${chain}`);
      }
      
      const address = await service.generateAddress(user.addressIndex);
      
      logger.info(`Generated ${chain} deposit address for user ${telegramId}: ${address}`);
      
      return address;
    } catch (error) {
      logger.error(`Failed to get deposit address: ${error}`);
      throw error;
    }
  }
  
  /**
   * Get deposit history for a user
   */
  async getDepositHistory(telegramId: number): Promise<any[]> {
    try {
      const user = await prisma.user.findUnique({
        where: { telegramId: BigInt(telegramId) },
        include: {
          deposits: {
            orderBy: { createdAt: 'desc' },
            take: 50
          }
        }
      });
      
      if (!user) {
        return [];
      }
      
      return user.deposits.map(d => ({
        txHash: d.txHash,
        chain: d.chain,
        currency: d.currency,
        amount: d.amount,
        status: d.status,
        confirmedAt: d.confirmedAt,
        sweptAt: d.sweptAt
      }));
    } catch (error) {
      logger.error(`Failed to get deposit history: ${error}`);
      throw error;
    }
  }
}

// Export system instance
export const depositSystem = new CryptoDepositSystem();

// Start system if run directly
if (require.main === module) {
  depositSystem.start().catch((error) => {
    logger.error(`Failed to start system: ${error}`);
    process.exit(1);
  });
}
