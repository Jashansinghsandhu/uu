import * as dotenv from 'dotenv';
import * as crypto from 'crypto';

dotenv.config();

/**
 * Configuration module for the crypto deposit system
 * Loads and validates all environment variables
 */

class Config {
  // Database
  public readonly DATABASE_URL: string;
  
  // Redis
  public readonly REDIS_HOST: string;
  public readonly REDIS_PORT: number;
  public readonly REDIS_PASSWORD?: string;
  
  // Master Wallet
  private readonly MASTER_MNEMONIC_ENCRYPTED: string;
  private readonly MNEMONIC_ENCRYPTION_KEY?: string;
  
  // Hot Wallet
  public readonly HOT_WALLET_PRIVATE_KEY: string;
  
  // Master Cold Wallets
  public readonly MASTER_WALLETS: {
    ETH: string;
    BNB: string;
    BASE: string;
    TRON: string;
    SOLANA: string;
    TON: string;
  };
  
  // RPC Endpoints
  public readonly RPC_ENDPOINTS: {
    ETH: string;
    BNB: string;
    BASE: string;
    TRON: string;
    SOLANA: string;
    TON: string;
  };
  
  // API Keys
  public readonly API_KEYS: {
    ETHERSCAN: string;
    BSCSCAN: string;
    BASESCAN: string;
    TRONSCAN: string;
    SOLSCAN: string;
    TONSCAN: string;
  };
  
  // Confirmations
  public readonly CONFIRMATIONS: {
    ETH: number;
    BNB: number;
    BASE: number;
    TRON: number;
    SOLANA: number;
    TON: number;
  };
  
  // Gas Buffers
  public readonly GAS_BUFFERS: {
    ETH: number;
    BNB: number;
    BASE: number;
    TRON: number;
    SOLANA: number;
    TON: number;
  };
  
  // Deposits
  public readonly MIN_DEPOSIT_USD: number;
  
  // Monitoring
  public readonly BLOCK_SCAN_INTERVAL: number;
  public readonly SWEEP_QUEUE_INTERVAL: number;
  public readonly PRICE_UPDATE_INTERVAL: number;
  
  // Alerts
  public readonly ALERT_WEBHOOK_URL?: string;
  public readonly ALERT_EMAIL?: string;
  
  // System
  public readonly NODE_ENV: string;
  public readonly LOG_LEVEL: string;
  public readonly LOG_FILE: string;
  
  // Feature Flags
  public readonly ENABLE_AUTO_SWEEP: boolean;
  public readonly ENABLE_GAS_STATION: boolean;
  public readonly ENABLE_ALERTS: boolean;

  constructor() {
    // Database
    this.DATABASE_URL = this.getEnvOrThrow('DATABASE_URL');
    
    // Redis
    this.REDIS_HOST = this.getEnv('REDIS_HOST', 'localhost');
    this.REDIS_PORT = parseInt(this.getEnv('REDIS_PORT', '6379'));
    this.REDIS_PASSWORD = this.getEnv('REDIS_PASSWORD');
    
    // Master Wallet
    this.MASTER_MNEMONIC_ENCRYPTED = this.getEnvOrThrow('MASTER_MNEMONIC');
    this.MNEMONIC_ENCRYPTION_KEY = this.getEnv('MNEMONIC_ENCRYPTION_KEY');
    
    // Hot Wallet
    this.HOT_WALLET_PRIVATE_KEY = this.getEnvOrThrow('HOT_WALLET_PRIVATE_KEY');
    
    // Master Cold Wallets
    this.MASTER_WALLETS = {
      ETH: this.getEnvOrThrow('MASTER_WALLET_ETH'),
      BNB: this.getEnvOrThrow('MASTER_WALLET_BNB'),
      BASE: this.getEnvOrThrow('MASTER_WALLET_BASE'),
      TRON: this.getEnvOrThrow('MASTER_WALLET_TRON'),
      SOLANA: this.getEnvOrThrow('MASTER_WALLET_SOLANA'),
      TON: this.getEnvOrThrow('MASTER_WALLET_TON'),
    };
    
    // RPC Endpoints
    this.RPC_ENDPOINTS = {
      ETH: this.getEnvOrThrow('RPC_ETH'),
      BNB: this.getEnvOrThrow('RPC_BNB'),
      BASE: this.getEnvOrThrow('RPC_BASE'),
      TRON: this.getEnvOrThrow('RPC_TRON'),
      SOLANA: this.getEnvOrThrow('RPC_SOLANA'),
      TON: this.getEnvOrThrow('RPC_TON'),
    };
    
    // API Keys
    this.API_KEYS = {
      ETHERSCAN: this.getEnvOrThrow('ETHERSCAN_API_KEY'),
      BSCSCAN: this.getEnvOrThrow('BSCSCAN_API_KEY'),
      BASESCAN: this.getEnvOrThrow('BASESCAN_API_KEY'),
      TRONSCAN: this.getEnvOrThrow('TRONSCAN_API_KEY'),
      SOLSCAN: this.getEnvOrThrow('SOLSCAN_API_KEY'),
      TONSCAN: this.getEnvOrThrow('TONSCAN_API_KEY'),
    };
    
    // Confirmations
    this.CONFIRMATIONS = {
      ETH: parseInt(this.getEnv('CONFIRMATIONS_ETH', '6')),
      BNB: parseInt(this.getEnv('CONFIRMATIONS_BNB', '2')),
      BASE: parseInt(this.getEnv('CONFIRMATIONS_BASE', '2')),
      TRON: parseInt(this.getEnv('CONFIRMATIONS_TRON', '19')),
      SOLANA: parseInt(this.getEnv('CONFIRMATIONS_SOLANA', '32')),
      TON: parseInt(this.getEnv('CONFIRMATIONS_TON', '5')),
    };
    
    // Gas Buffers
    this.GAS_BUFFERS = {
      ETH: parseFloat(this.getEnv('GAS_BUFFER_ETH', '0.001')),
      BNB: parseFloat(this.getEnv('GAS_BUFFER_BNB', '0.001')),
      BASE: parseFloat(this.getEnv('GAS_BUFFER_BASE', '0.0001')),
      TRON: parseFloat(this.getEnv('GAS_BUFFER_TRON', '10')),
      SOLANA: parseFloat(this.getEnv('GAS_BUFFER_SOLANA', '0.001')),
      TON: parseFloat(this.getEnv('GAS_BUFFER_TON', '0.05')),
    };
    
    // Deposits
    this.MIN_DEPOSIT_USD = parseFloat(this.getEnv('MIN_DEPOSIT_USD', '10.0'));
    
    // Monitoring
    this.BLOCK_SCAN_INTERVAL = parseInt(this.getEnv('BLOCK_SCAN_INTERVAL', '30000'));
    this.SWEEP_QUEUE_INTERVAL = parseInt(this.getEnv('SWEEP_QUEUE_INTERVAL', '10000'));
    this.PRICE_UPDATE_INTERVAL = parseInt(this.getEnv('PRICE_UPDATE_INTERVAL', '300000'));
    
    // Alerts
    this.ALERT_WEBHOOK_URL = this.getEnv('ALERT_WEBHOOK_URL');
    this.ALERT_EMAIL = this.getEnv('ALERT_EMAIL');
    
    // System
    this.NODE_ENV = this.getEnv('NODE_ENV', 'development');
    this.LOG_LEVEL = this.getEnv('LOG_LEVEL', 'info');
    this.LOG_FILE = this.getEnv('LOG_FILE', 'logs/deposit-system.log');
    
    // Feature Flags
    this.ENABLE_AUTO_SWEEP = this.getEnv('ENABLE_AUTO_SWEEP', 'true') === 'true';
    this.ENABLE_GAS_STATION = this.getEnv('ENABLE_GAS_STATION', 'true') === 'true';
    this.ENABLE_ALERTS = this.getEnv('ENABLE_ALERTS', 'true') === 'true';
  }
  
  /**
   * Get decrypted master mnemonic
   * Decryption happens in-memory only, never stored
   */
  public getMasterMnemonic(): string {
    if (this.MNEMONIC_ENCRYPTION_KEY) {
      return this.decrypt(this.MASTER_MNEMONIC_ENCRYPTED, this.MNEMONIC_ENCRYPTION_KEY);
    }
    return this.MASTER_MNEMONIC_ENCRYPTED;
  }
  
  private getEnv(key: string, defaultValue?: string): string {
    const value = process.env[key];
    if (value !== undefined) {
      return value;
    }
    if (defaultValue !== undefined) {
      return defaultValue;
    }
    return '';
  }
  
  private getEnvOrThrow(key: string): string {
    const value = process.env[key];
    if (!value) {
      throw new Error(`Environment variable ${key} is required but not set`);
    }
    return value;
  }
  
  /**
   * Simple AES-256-GCM decryption for mnemonic
   * Note: For production, use a proper key derivation function with random salt
   */
  private decrypt(encryptedText: string, key: string): string {
    try {
      // If not encrypted (for development), return as-is
      if (!encryptedText.includes(':')) {
        return encryptedText;
      }
      
      const parts = encryptedText.split(':');
      if (parts.length !== 4) {
        throw new Error('Invalid encrypted text format');
      }
      
      const salt = Buffer.from(parts[0], 'hex');
      const iv = Buffer.from(parts[1], 'hex');
      const authTag = Buffer.from(parts[2], 'hex');
      const encrypted = Buffer.from(parts[3], 'hex');
      
      const keyBuffer = crypto.scryptSync(key, salt, 32);
      const decipher = crypto.createDecipheriv('aes-256-gcm', keyBuffer, iv);
      decipher.setAuthTag(authTag);
      
      let decrypted = decipher.update(encrypted, undefined, 'utf8');
      decrypted += decipher.final('utf8');
      
      return decrypted;
    } catch (error) {
      throw new Error('Failed to decrypt master mnemonic. Check MNEMONIC_ENCRYPTION_KEY');
    }
  }
}

export const config = new Config();
