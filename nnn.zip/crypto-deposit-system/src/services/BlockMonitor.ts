import { PrismaClient } from '@prisma/client';
import { Redis } from 'ioredis';
import { config } from '../config';
import { logger } from '../utils/logger';
import { EvmService } from './EvmService';
import { TronService } from './TronService';
import { SolanaService } from './SolanaService';
import { TonService } from './TonService';
import { SweeperQueue } from './SweeperQueue';

const prisma = new PrismaClient();

/**
 * BlockMonitor scans blockchains for incoming deposits
 * Uses Redis to maintain scanning state for idempotency
 */
export class BlockMonitor {
  private redis: Redis;
  private services: Map<string, any> = new Map();
  private sweeperQueue: SweeperQueue;
  private isRunning: boolean = false;
  private intervals: NodeJS.Timeout[] = [];
  
  constructor(sweeperQueue: SweeperQueue) {
    this.sweeperQueue = sweeperQueue;
    
    // Initialize Redis
    this.redis = new Redis({
      host: config.REDIS_HOST,
      port: config.REDIS_PORT,
      password: config.REDIS_PASSWORD
    });
    
    // Initialize blockchain services
    this.initializeServices();
  }
  
  /**
   * Initialize blockchain service instances
   */
  private initializeServices(): void {
    const mnemonic = config.getMasterMnemonic();
    
    this.services.set('eth', new EvmService(
      mnemonic,
      config.RPC_ENDPOINTS.ETH,
      config.MASTER_WALLETS.ETH,
      1,
      'Ethereum'
    ));
    
    this.services.set('bsc', new EvmService(
      mnemonic,
      config.RPC_ENDPOINTS.BNB,
      config.MASTER_WALLETS.BNB,
      56,
      'BSC'
    ));
    
    this.services.set('base', new EvmService(
      mnemonic,
      config.RPC_ENDPOINTS.BASE,
      config.MASTER_WALLETS.BASE,
      8453,
      'Base'
    ));
    
    this.services.set('tron', new TronService(
      mnemonic,
      config.RPC_ENDPOINTS.TRON,
      config.MASTER_WALLETS.TRON
    ));
    
    this.services.set('solana', new SolanaService(
      mnemonic,
      config.RPC_ENDPOINTS.SOLANA,
      config.MASTER_WALLETS.SOLANA
    ));
    
    this.services.set('ton', new TonService(
      mnemonic,
      config.RPC_ENDPOINTS.TON,
      config.MASTER_WALLETS.TON
    ));
  }
  
  /**
   * Start monitoring all chains
   */
  async start(): Promise<void> {
    if (this.isRunning) {
      logger.warn('BlockMonitor is already running');
      return;
    }
    
    this.isRunning = true;
    logger.info('Starting BlockMonitor');
    
    // Initialize system state for each chain if not exists
    await this.initializeSystemState();
    
    // Start monitoring each chain
    const chains = ['eth', 'bsc', 'base', 'tron', 'solana', 'ton'];
    
    for (const chain of chains) {
      const interval = setInterval(async () => {
        await this.scanChain(chain);
      }, config.BLOCK_SCAN_INTERVAL);
      
      this.intervals.push(interval);
      
      // Initial scan
      await this.scanChain(chain);
    }
    
    logger.info('BlockMonitor started for all chains');
  }
  
  /**
   * Stop monitoring
   */
  async stop(): Promise<void> {
    this.isRunning = false;
    
    // Clear all intervals
    for (const interval of this.intervals) {
      clearInterval(interval);
    }
    this.intervals = [];
    
    await this.redis.quit();
    await prisma.$disconnect();
    
    logger.info('BlockMonitor stopped');
  }
  
  /**
   * Initialize system state for each chain
   */
  private async initializeSystemState(): Promise<void> {
    const chains = ['eth', 'bsc', 'base', 'tron', 'solana', 'ton'];
    
    for (const chain of chains) {
      const exists = await prisma.systemState.findUnique({
        where: { chain }
      });
      
      if (!exists) {
        const service = this.services.get(chain);
        if (service) {
          try {
            const currentBlock = await service.getCurrentBlock();
            
            await prisma.systemState.create({
              data: {
                chain,
                lastScannedBlock: BigInt(currentBlock)
              }
            });
            
            logger.info(`Initialized system state for ${chain} at block ${currentBlock}`);
          } catch (error) {
            logger.error(`Failed to initialize ${chain}: ${error}`);
          }
        }
      }
    }
  }
  
  /**
   * Scan a specific chain for deposits
   */
  private async scanChain(chain: string): Promise<void> {
    try {
      const service = this.services.get(chain);
      if (!service) {
        logger.error(`Service not found for chain: ${chain}`);
        return;
      }
      
      // Get last scanned block from database
      const systemState = await prisma.systemState.findUnique({
        where: { chain }
      });
      
      if (!systemState) {
        logger.error(`System state not found for chain: ${chain}`);
        return;
      }
      
      const lastScannedBlock = Number(systemState.lastScannedBlock);
      const currentBlock = await service.getCurrentBlock();
      
      if (currentBlock <= lastScannedBlock) {
        // No new blocks to scan
        return;
      }
      
      logger.info(`Scanning ${chain} from block ${lastScannedBlock + 1} to ${currentBlock}`);
      
      // Get all users with deposit addresses on this chain
      const users = await prisma.user.findMany({
        select: {
          id: true,
          addressIndex: true
        }
      });
      
      // Scan each user's address
      for (const user of users) {
        try {
          const address = await service.generateAddress(user.addressIndex);
          const transactions = await service.scanAddress(address, lastScannedBlock + 1);
          
          for (const tx of transactions) {
            await this.processTransaction(chain, user.id, user.addressIndex, address, tx);
          }
        } catch (error) {
          logger.error(`Failed to scan address for user ${user.id}: ${error}`);
        }
      }
      
      // Update last scanned block
      await prisma.systemState.update({
        where: { chain },
        data: {
          lastScannedBlock: BigInt(currentBlock),
          lastScannedAt: new Date()
        }
      });
      
      logger.info(`Completed scanning ${chain} up to block ${currentBlock}`);
    } catch (error) {
      logger.error(`Error scanning chain ${chain}: ${error}`);
      
      // Update error count
      await prisma.systemState.update({
        where: { chain },
        data: {
          errorCount: { increment: 1 },
          lastError: error instanceof Error ? error.message : String(error),
          lastErrorAt: new Date()
        }
      });
      
      // Create alert if too many errors
      const state = await prisma.systemState.findUnique({ where: { chain } });
      if (state && state.errorCount > 5) {
        await prisma.alert.create({
          data: {
            type: 'BLOCK_SCAN_ERROR',
            severity: 'ERROR',
            message: `Block scanning failing for ${chain}`,
            details: JSON.stringify({
              chain,
              errorCount: state.errorCount,
              lastError: state.lastError
            })
          }
        });
      }
    }
  }
  
  /**
   * Process a detected transaction
   */
  private async processTransaction(
    chain: string,
    userId: number,
    userIndex: number,
    depositAddress: string,
    tx: any
  ): Promise<void> {
    try {
      // Check if transaction already exists
      const existing = await prisma.deposit.findUnique({
        where: { txHash: tx.hash }
      });
      
      if (existing) {
        // Update confirmations if pending
        if (existing.status === 'PENDING') {
          const service = this.services.get(chain);
          const txInfo = await service.getTransaction(tx.hash);
          
          await prisma.deposit.update({
            where: { id: existing.id },
            data: {
              confirmations: txInfo.confirmations
            }
          });
          
          // Check if now confirmed
          if (txInfo.confirmations >= this.getRequiredConfirmations(chain)) {
            await this.handleConfirmedDeposit(existing.id, chain, userIndex);
          }
        }
        return;
      }
      
      // Create new deposit record
      const currency = tx.isToken ? (tx.tokenSymbol || 'TOKEN') : this.getNativeCurrency(chain);
      const amount = tx.isToken ? (tx.tokenAmount?.toString() || '0') : tx.value.toString();
      
      const deposit = await prisma.deposit.create({
        data: {
          userId,
          txHash: tx.hash,
          chain,
          currency,
          amount,
          depositAddress,
          fromAddress: tx.from,
          status: 'PENDING',
          confirmations: 0,
          requiredConf: this.getRequiredConfirmations(chain)
        }
      });
      
      logger.info(`New deposit detected: ${tx.hash} for user ${userId} on ${chain}`);
      
      // Check if already confirmed
      const service = this.services.get(chain);
      const txInfo = await service.getTransaction(tx.hash);
      
      if (txInfo.confirmations >= this.getRequiredConfirmations(chain)) {
        await this.handleConfirmedDeposit(deposit.id, chain, userIndex);
      }
    } catch (error) {
      logger.error(`Failed to process transaction ${tx.hash}: ${error}`);
    }
  }
  
  /**
   * Handle a confirmed deposit
   */
  private async handleConfirmedDeposit(depositId: number, chain: string, userIndex: number): Promise<void> {
    try {
      const deposit = await prisma.deposit.findUnique({
        where: { id: depositId }
      });
      
      if (!deposit || deposit.status !== 'PENDING') {
        return;
      }
      
      // Update status to confirmed
      await prisma.deposit.update({
        where: { id: depositId },
        data: {
          status: 'CONFIRMED',
          confirmedAt: new Date()
        }
      });
      
      logger.info(`Deposit ${depositId} confirmed, initiating sweep`);
      
      // Check minimum deposit amount
      // TODO: Convert amount to USD and check against MIN_DEPOSIT_USD
      
      // Create sweep queue entry
      await prisma.sweepQueue.create({
        data: {
          depositId,
          chain,
          currency: deposit.currency,
          depositAddress: deposit.depositAddress,
          amount: deposit.amount,
          needsGas: this.isTokenDeposit(deposit.currency),
          status: 'PENDING'
        }
      });
      
      // Add to sweep queue
      if (config.ENABLE_AUTO_SWEEP) {
        await this.sweeperQueue.addSweepJob({
          depositId,
          chain,
          currency: deposit.currency,
          depositAddress: deposit.depositAddress,
          amount: deposit.amount,
          userIndex,
          isToken: this.isTokenDeposit(deposit.currency),
          tokenContract: this.getTokenContract(chain, deposit.currency)
        });
      }
    } catch (error) {
      logger.error(`Failed to handle confirmed deposit ${depositId}: ${error}`);
    }
  }
  
  /**
   * Get required confirmations for a chain
   */
  private getRequiredConfirmations(chain: string): number {
    const confMap: Record<string, number> = {
      'eth': config.CONFIRMATIONS.ETH,
      'bsc': config.CONFIRMATIONS.BNB,
      'base': config.CONFIRMATIONS.BASE,
      'tron': config.CONFIRMATIONS.TRON,
      'solana': config.CONFIRMATIONS.SOLANA,
      'ton': config.CONFIRMATIONS.TON
    };
    
    return confMap[chain] || 6;
  }
  
  /**
   * Get native currency symbol for chain
   */
  private getNativeCurrency(chain: string): string {
    const currencyMap: Record<string, string> = {
      'eth': 'ETH',
      'bsc': 'BNB',
      'base': 'ETH',
      'tron': 'TRX',
      'solana': 'SOL',
      'ton': 'TON'
    };
    
    return currencyMap[chain] || 'UNKNOWN';
  }
  
  /**
   * Check if currency is a token (not native coin)
   */
  private isTokenDeposit(currency: string): boolean {
    return currency.includes('USDT') || currency.includes('TOKEN');
  }
  
  /**
   * Get token contract address
   */
  private getTokenContract(chain: string, currency: string): string | undefined {
    // Standard USDT contracts
    const usdtContracts: Record<string, string> = {
      'eth': '0xdAC17F958D2ee523a2206206994597C13D831ec7',
      'bsc': '0x55d398326f99059fF775485246999027B3197955',
      'base': '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
      'tron': 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t'
    };
    
    if (currency.includes('USDT')) {
      return usdtContracts[chain];
    }
    
    return undefined;
  }
}
