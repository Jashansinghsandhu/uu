import { Queue, Worker, Job } from 'bullmq';
import { Redis } from 'ioredis';
import { config } from '../config';
import { PrismaClient } from '@prisma/client';
import { logger } from '../utils/logger';
import { EvmService } from './EvmService';
import { TronService } from './TronService';
import { SolanaService } from './SolanaService';
import { TonService } from './TonService';

const prisma = new PrismaClient();

/**
 * Sweep job data interface
 */
interface SweepJobData {
  depositId: number;
  chain: string;
  currency: string;
  depositAddress: string;
  amount: string;
  userIndex: number;
  isToken: boolean;
  tokenContract?: string;
}

/**
 * SweeperQueue manages the async workflow of funding gas and sweeping deposits
 * Implements the "Gas Station" pattern for token deposits
 */
export class SweeperQueue {
  private queue: Queue<SweepJobData>;
  private worker: Worker<SweepJobData>;
  private redis: Redis;
  
  // Service instances
  private services: Map<string, any> = new Map();
  
  constructor() {
    // Initialize Redis connection
    this.redis = new Redis({
      host: config.REDIS_HOST,
      port: config.REDIS_PORT,
      password: config.REDIS_PASSWORD,
      maxRetriesPerRequest: null
    });
    
    // Initialize BullMQ queue
    this.queue = new Queue<SweepJobData>('sweep-queue', {
      connection: this.redis
    });
    
    // Initialize worker
    this.worker = new Worker<SweepJobData>(
      'sweep-queue',
      async (job) => await this.processSweepJob(job),
      {
        connection: this.redis,
        concurrency: 5, // Process 5 sweeps concurrently
        limiter: {
          max: 10, // Max 10 jobs
          duration: 1000 // per second
        }
      }
    );
    
    // Initialize blockchain services
    this.initializeServices();
    
    // Set up worker event handlers
    this.setupWorkerEvents();
  }
  
  /**
   * Initialize blockchain service instances
   */
  private initializeServices() {
    const mnemonic = config.getMasterMnemonic();
    
    // EVM services
    this.services.set('eth', new EvmService(
      mnemonic,
      config.RPC_ENDPOINTS.ETH,
      config.MASTER_WALLETS.ETH,
      1,
      'Ethereum'
    ));
    
    this.services.set('bsc', new EvmService(
      mnemonic,
      config.RPC_ENDPOINTS.BNB,
      config.MASTER_WALLETS.BNB,
      56,
      'BSC'
    ));
    
    this.services.set('base', new EvmService(
      mnemonic,
      config.RPC_ENDPOINTS.BASE,
      config.MASTER_WALLETS.BASE,
      8453,
      'Base'
    ));
    
    // Non-EVM services
    this.services.set('tron', new TronService(
      mnemonic,
      config.RPC_ENDPOINTS.TRON,
      config.MASTER_WALLETS.TRON
    ));
    
    this.services.set('solana', new SolanaService(
      mnemonic,
      config.RPC_ENDPOINTS.SOLANA,
      config.MASTER_WALLETS.SOLANA
    ));
    
    this.services.set('ton', new TonService(
      mnemonic,
      config.RPC_ENDPOINTS.TON,
      config.MASTER_WALLETS.TON
    ));
  }
  
  /**
   * Add a sweep job to the queue
   */
  async addSweepJob(data: SweepJobData): Promise<void> {
    try {
      await this.queue.add('sweep', data, {
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 10000 // Start with 10 second delay
        }
      });
      
      logger.info(`Added sweep job for deposit ${data.depositId}`);
    } catch (error) {
      logger.error(`Failed to add sweep job: ${error}`);
      throw error;
    }
  }
  
  /**
   * Process a sweep job
   * Implements the Gas Station pattern
   */
  private async processSweepJob(job: Job<SweepJobData>): Promise<void> {
    const { depositId, chain, currency, depositAddress, amount, userIndex, isToken, tokenContract } = job.data;
    
    logger.info(`Processing sweep job ${job.id} for deposit ${depositId}`);
    
    try {
      const service = this.services.get(chain);
      if (!service) {
        throw new Error(`Service not found for chain: ${chain}`);
      }
      
      // Update sweep queue status
      await prisma.sweepQueue.update({
        where: { depositId },
        data: { status: 'SWEEPING', attempts: { increment: 1 } }
      });
      
      let txHash: string;
      
      if (isToken && tokenContract) {
        // Token sweep - need to check and fund gas if necessary
        await this.handleTokenSweep(service, depositAddress, amount, tokenContract, chain, userIndex, depositId);
        
        // After gas is funded (if needed), sweep the token
        const privateKey = await service['derivePrivateKey'](userIndex);
        txHash = await service.sweepToken(
          privateKey,
          this.getMasterWallet(chain),
          BigInt(amount),
          tokenContract
        );
      } else {
        // Native coin sweep - can sweep directly
        const privateKey = await service['derivePrivateKey'](userIndex);
        
        // Calculate sweep amount (total - gas)
        const balance = await service.getBalance(depositAddress);
        const gasEstimate = await service.estimateGas(depositAddress, this.getMasterWallet(chain), balance);
        const sweepAmount = balance - gasEstimate;
        
        if (sweepAmount <= 0n) {
          throw new Error('Insufficient balance to cover gas');
        }
        
        txHash = await service.sweep(
          privateKey,
          this.getMasterWallet(chain),
          sweepAmount
        );
      }
      
      // Update database
      await prisma.deposit.update({
        where: { id: depositId },
        data: {
          status: 'SWEPT',
          sweepTxHash: txHash,
          sweptAt: new Date()
        }
      });
      
      await prisma.sweepQueue.update({
        where: { depositId },
        data: {
          status: 'COMPLETED',
          processedAt: new Date()
        }
      });
      
      logger.info(`Successfully swept deposit ${depositId}, tx: ${txHash}`);
    } catch (error) {
      logger.error(`Failed to process sweep job: ${error}`);
      
      // Update database with error
      await prisma.deposit.update({
        where: { id: depositId },
        data: {
          status: 'FAILED',
          errorMessage: error instanceof Error ? error.message : String(error),
          retryCount: { increment: 1 }
        }
      });
      
      await prisma.sweepQueue.update({
        where: { depositId },
        data: {
          status: 'FAILED',
          errorMessage: error instanceof Error ? error.message : String(error)
        }
      });
      
      // Create alert
      await this.createAlert(depositId, error);
      
      throw error;
    }
  }
  
  /**
   * Handle token sweep with gas funding
   */
  private async handleTokenSweep(
    service: any,
    depositAddress: string,
    amount: string,
    tokenContract: string,
    chain: string,
    userIndex: number,
    depositId: number
  ): Promise<void> {
    // Check if address has enough gas
    const balance = await service.getBalance(depositAddress);
    const gasNeeded = await service.estimateGas(depositAddress, this.getMasterWallet(chain), 0n, true);
    
    if (balance < gasNeeded) {
      logger.info(`Funding gas for deposit ${depositId}: ${gasNeeded} needed, ${balance} available`);
      
      // Update status
      await prisma.sweepQueue.update({
        where: { depositId },
        data: { 
          status: 'GAS_FUNDING',
          needsGas: true
        }
      });
      
      // Fund gas from hot wallet
      const gasBuffer = this.getGasBuffer(chain);
      const fundAmount = gasNeeded + gasBuffer;
      
      const gasTxHash = await service.fundGas(
        config.HOT_WALLET_PRIVATE_KEY,
        depositAddress,
        fundAmount
      );
      
      logger.info(`Gas funded for deposit ${depositId}, tx: ${gasTxHash}`);
      
      // Update database
      await prisma.deposit.update({
        where: { id: depositId },
        data: { gasFundingTxHash: gasTxHash }
      });
      
      await prisma.sweepQueue.update({
        where: { depositId },
        data: {
          status: 'GAS_FUNDED',
          gasFunded: true,
          gasFundingTxHash: gasTxHash
        }
      });
      
      // Wait for gas funding to be confirmed
      await this.waitForConfirmation(service, gasTxHash, chain);
    }
  }
  
  /**
   * Wait for transaction confirmation
   */
  private async waitForConfirmation(service: any, txHash: string, chain: string): Promise<void> {
    const requiredConf = this.getRequiredConfirmations(chain);
    let confirmations = 0;
    
    while (confirmations < requiredConf) {
      await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
      
      try {
        const tx = await service.getTransaction(txHash);
        confirmations = tx.confirmations;
        logger.info(`Transaction ${txHash} has ${confirmations}/${requiredConf} confirmations`);
      } catch (error) {
        logger.warn(`Failed to check transaction confirmations: ${error}`);
      }
    }
  }
  
  /**
   * Get master wallet address for chain
   */
  private getMasterWallet(chain: string): string {
    const walletMap: Record<string, string> = {
      'eth': config.MASTER_WALLETS.ETH,
      'bsc': config.MASTER_WALLETS.BNB,
      'base': config.MASTER_WALLETS.BASE,
      'tron': config.MASTER_WALLETS.TRON,
      'solana': config.MASTER_WALLETS.SOLANA,
      'ton': config.MASTER_WALLETS.TON
    };
    
    return walletMap[chain] || '';
  }
  
  /**
   * Get gas buffer for chain
   */
  private getGasBuffer(chain: string): bigint {
    const bufferMap: Record<string, number> = {
      'eth': config.GAS_BUFFERS.ETH,
      'bsc': config.GAS_BUFFERS.BNB,
      'base': config.GAS_BUFFERS.BASE,
      'tron': config.GAS_BUFFERS.TRON,
      'solana': config.GAS_BUFFERS.SOLANA,
      'ton': config.GAS_BUFFERS.TON
    };
    
    const buffer = bufferMap[chain] || 0;
    
    // Convert to appropriate units
    if (chain === 'eth' || chain === 'bsc' || chain === 'base') {
      return BigInt(Math.floor(buffer * 1e18)); // Convert to wei
    } else if (chain === 'tron') {
      return BigInt(Math.floor(buffer * 1e6)); // Convert to sun
    } else if (chain === 'solana') {
      return BigInt(Math.floor(buffer * 1e9)); // Convert to lamports
    } else if (chain === 'ton') {
      return BigInt(Math.floor(buffer * 1e9)); // Convert to nanotons
    }
    
    return 0n;
  }
  
  /**
   * Get required confirmations for chain
   */
  private getRequiredConfirmations(chain: string): number {
    const confMap: Record<string, number> = {
      'eth': config.CONFIRMATIONS.ETH,
      'bsc': config.CONFIRMATIONS.BNB,
      'base': config.CONFIRMATIONS.BASE,
      'tron': config.CONFIRMATIONS.TRON,
      'solana': config.CONFIRMATIONS.SOLANA,
      'ton': config.CONFIRMATIONS.TON
    };
    
    return confMap[chain] || 6;
  }
  
  /**
   * Create alert for failed sweep
   */
  private async createAlert(depositId: number, error: any): Promise<void> {
    try {
      await prisma.alert.create({
        data: {
          type: 'SWEEP_FAILED',
          severity: 'ERROR',
          message: `Failed to sweep deposit ${depositId}`,
          details: JSON.stringify({
            depositId,
            error: error instanceof Error ? error.message : String(error)
          })
        }
      });
    } catch (e) {
      logger.error(`Failed to create alert: ${e}`);
    }
  }
  
  /**
   * Set up worker event handlers
   */
  private setupWorkerEvents(): void {
    this.worker.on('completed', (job) => {
      logger.info(`Job ${job.id} completed`);
    });
    
    this.worker.on('failed', (job, err) => {
      logger.error(`Job ${job?.id} failed: ${err.message}`);
    });
    
    this.worker.on('error', (err) => {
      logger.error(`Worker error: ${err.message}`);
    });
  }
  
  /**
   * Graceful shutdown
   */
  async close(): Promise<void> {
    await this.worker.close();
    await this.queue.close();
    await this.redis.quit();
    await prisma.$disconnect();
  }
}
