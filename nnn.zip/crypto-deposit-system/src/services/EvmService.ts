import { ethers } from 'ethers';
import * as bip39 from 'bip39';
import { BIP32Factory } from 'bip32';
import * as ecc from 'tiny-secp256k1';
import { CryptoService, TransactionInfo, IncomingTransaction, TokenTransfer } from './CryptoService';

const bip32 = BIP32Factory(ecc);

/**
 * EVM-compatible chain service
 * Supports Ethereum, BSC (BNB Chain), Base, and other EVM chains
 */
export class EvmService extends CryptoService {
  private provider: ethers.JsonRpcProvider;
  private chainId: number;
  private chainName: string;
  
  // Standard ERC20 ABI for token operations
  private readonly ERC20_ABI = [
    'function balanceOf(address) view returns (uint256)',
    'function transfer(address to, uint256 amount) returns (bool)',
    'function decimals() view returns (uint8)',
    'function symbol() view returns (string)'
  ];
  
  constructor(
    masterMnemonic: string,
    rpcEndpoint: string,
    masterWallet: string,
    chainId: number,
    chainName: string
  ) {
    super(masterMnemonic, rpcEndpoint, masterWallet);
    this.provider = new ethers.JsonRpcProvider(rpcEndpoint);
    this.chainId = chainId;
    this.chainName = chainName;
  }
  
  /**
   * Get BIP44 derivation path for EVM chains
   * m/44'/60'/0'/0/{index} for all EVM chains
   */
  protected getDerivationPath(index: number): string {
    return `m/44'/60'/0'/0/${index}`;
  }
  
  /**
   * Generate address for a user from master seed
   */
  async generateAddress(userIndex: number): Promise<string> {
    try {
      // Convert mnemonic to seed
      const seed = await bip39.mnemonicToSeed(this.masterMnemonic);
      
      // Derive key using BIP32
      const root = bip32.fromSeed(seed);
      const path = this.getDerivationPath(userIndex);
      const child = root.derivePath(path);
      
      if (!child.privateKey) {
        throw new Error('Failed to derive private key');
      }
      
      // Create wallet from private key
      const wallet = new ethers.Wallet(ethers.hexlify(child.privateKey));
      
      return wallet.address;
    } catch (error) {
      throw new Error(`Failed to generate address: ${error}`);
    }
  }
  
  /**
   * Derive private key for a user (used only for signing, never stored)
   */
  protected async derivePrivateKey(userIndex: number): Promise<string> {
    try {
      const seed = await bip39.mnemonicToSeed(this.masterMnemonic);
      const root = bip32.fromSeed(seed);
      const path = this.getDerivationPath(userIndex);
      const child = root.derivePath(path);
      
      if (!child.privateKey) {
        throw new Error('Failed to derive private key');
      }
      
      return ethers.hexlify(child.privateKey);
    } catch (error) {
      throw new Error(`Failed to derive private key: ${error}`);
    }
  }
  
  /**
   * Get native coin balance (ETH, BNB, etc.)
   */
  async getBalance(address: string): Promise<bigint> {
    try {
      return await this.provider.getBalance(address);
    } catch (error) {
      throw new Error(`Failed to get balance: ${error}`);
    }
  }
  
  /**
   * Get ERC20 token balance
   */
  async getTokenBalance(address: string, tokenContract?: string): Promise<bigint> {
    if (!tokenContract) {
      throw new Error('Token contract address is required');
    }
    
    try {
      const contract = new ethers.Contract(tokenContract, this.ERC20_ABI, this.provider);
      const balance = await contract.balanceOf(address);
      return BigInt(balance.toString());
    } catch (error) {
      throw new Error(`Failed to get token balance: ${error}`);
    }
  }
  
  /**
   * Estimate gas for a transaction
   */
  async estimateGas(from: string, to: string, amount?: bigint, isToken: boolean = false): Promise<bigint> {
    try {
      let gasLimit: bigint;
      
      if (isToken && amount) {
        // Estimate gas for token transfer
        const contract = new ethers.Contract(to, this.ERC20_ABI, this.provider);
        const data = contract.interface.encodeFunctionData('transfer', [this.masterWallet, amount]);
        gasLimit = await this.provider.estimateGas({
          from,
          to,
          data
        });
      } else {
        // Estimate gas for native transfer
        gasLimit = await this.provider.estimateGas({
          from,
          to,
          value: amount || 0n
        });
      }
      
      // Get current gas price
      const feeData = await this.provider.getFeeData();
      const gasPrice = feeData.gasPrice || feeData.maxFeePerGas || 0n;
      
      // Return total cost (gas limit * gas price)
      return gasLimit * gasPrice;
    } catch (error) {
      throw new Error(`Failed to estimate gas: ${error}`);
    }
  }
  
  /**
   * Sweep native coin to master wallet
   */
  async sweep(privateKey: string, destination: string, amount: bigint): Promise<string> {
    try {
      const wallet = new ethers.Wallet(privateKey, this.provider);
      
      const tx = await wallet.sendTransaction({
        to: destination,
        value: amount
      });
      
      await tx.wait();
      return tx.hash;
    } catch (error) {
      throw new Error(`Failed to sweep: ${error}`);
    }
  }
  
  /**
   * Sweep ERC20 token to master wallet
   */
  async sweepToken(privateKey: string, destination: string, amount: bigint, tokenContract: string): Promise<string> {
    try {
      const wallet = new ethers.Wallet(privateKey, this.provider);
      const contract = new ethers.Contract(tokenContract, this.ERC20_ABI, wallet);
      
      const tx = await contract.transfer(destination, amount);
      await tx.wait();
      
      return tx.hash;
    } catch (error) {
      throw new Error(`Failed to sweep token: ${error}`);
    }
  }
  
  /**
   * Fund gas to an address for token sweeping
   */
  async fundGas(hotWalletKey: string, destination: string, gasAmount: bigint): Promise<string> {
    try {
      const wallet = new ethers.Wallet(hotWalletKey, this.provider);
      
      const tx = await wallet.sendTransaction({
        to: destination,
        value: gasAmount
      });
      
      await tx.wait();
      return tx.hash;
    } catch (error) {
      throw new Error(`Failed to fund gas: ${error}`);
    }
  }
  
  /**
   * Get current block number
   */
  async getCurrentBlock(): Promise<number> {
    try {
      return await this.provider.getBlockNumber();
    } catch (error) {
      throw new Error(`Failed to get current block: ${error}`);
    }
  }
  
  /**
   * Get transaction details with confirmations
   */
  async getTransaction(txHash: string): Promise<TransactionInfo> {
    try {
      const tx = await this.provider.getTransaction(txHash);
      if (!tx) {
        throw new Error('Transaction not found');
      }
      
      const receipt = await this.provider.getTransactionReceipt(txHash);
      const currentBlock = await this.getCurrentBlock();
      
      const confirmations = receipt 
        ? currentBlock - receipt.blockNumber + 1 
        : 0;
      
      const block = tx.blockNumber ? await this.provider.getBlock(tx.blockNumber) : null;
      
      // Parse token transfers from logs
      const tokenTransfers: TokenTransfer[] = [];
      if (receipt) {
        for (const log of receipt.logs) {
          // ERC20 Transfer event signature
          if (log.topics[0] === ethers.id('Transfer(address,address,uint256)')) {
            try {
              const from = ethers.getAddress('0x' + log.topics[1].slice(26));
              const to = ethers.getAddress('0x' + log.topics[2].slice(26));
              const value = BigInt(log.data);
              
              tokenTransfers.push({
                from,
                to,
                value,
                tokenAddress: log.address
              });
            } catch (e) {
              // Skip invalid logs
            }
          }
        }
      }
      
      return {
        hash: tx.hash,
        from: tx.from,
        to: tx.to || '',
        value: tx.value,
        blockNumber: tx.blockNumber || 0,
        confirmations,
        timestamp: block?.timestamp || 0,
        status: receipt ? (receipt.status === 1 ? 'confirmed' : 'failed') : 'pending',
        gasUsed: receipt?.gasUsed,
        tokenTransfers
      };
    } catch (error) {
      throw new Error(`Failed to get transaction: ${error}`);
    }
  }
  
  /**
   * Scan address for incoming transactions
   */
  async scanAddress(address: string, fromBlock: number): Promise<IncomingTransaction[]> {
    try {
      const currentBlock = await this.getCurrentBlock();
      const transactions: IncomingTransaction[] = [];
      
      // Scan native transfers
      // Note: This is a simplified version. In production, use block explorer APIs
      // for more efficient scanning (Etherscan, BSCScan, etc.)
      
      for (let blockNum = fromBlock; blockNum <= currentBlock; blockNum++) {
        const block = await this.provider.getBlock(blockNum, true);
        if (!block || !block.prefetchedTransactions) continue;
        
        for (const tx of block.prefetchedTransactions) {
          if (tx.to?.toLowerCase() === address.toLowerCase() && tx.value > 0n) {
            transactions.push({
              hash: tx.hash,
              from: tx.from,
              to: tx.to,
              value: tx.value,
              blockNumber: blockNum,
              timestamp: block.timestamp,
              isToken: false
            });
          }
        }
      }
      
      return transactions;
    } catch (error) {
      throw new Error(`Failed to scan address: ${error}`);
    }
  }
  
  /**
   * Get token information
   */
  async getTokenInfo(tokenContract: string): Promise<{ symbol: string; decimals: number }> {
    try {
      const contract = new ethers.Contract(tokenContract, this.ERC20_ABI, this.provider);
      const [symbol, decimals] = await Promise.all([
        contract.symbol(),
        contract.decimals()
      ]);
      
      return { symbol, decimals: Number(decimals) };
    } catch (error) {
      throw new Error(`Failed to get token info: ${error}`);
    }
  }
}

/**
 * Factory function to create EVM services for different chains
 */
export class EvmServiceFactory {
  static createEthereumService(masterMnemonic: string, rpcEndpoint: string, masterWallet: string): EvmService {
    return new EvmService(masterMnemonic, rpcEndpoint, masterWallet, 1, 'Ethereum');
  }
  
  static createBnbService(masterMnemonic: string, rpcEndpoint: string, masterWallet: string): EvmService {
    return new EvmService(masterMnemonic, rpcEndpoint, masterWallet, 56, 'BSC');
  }
  
  static createBaseService(masterMnemonic: string, rpcEndpoint: string, masterWallet: string): EvmService {
    return new EvmService(masterMnemonic, rpcEndpoint, masterWallet, 8453, 'Base');
  }
}
