import {
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  SystemProgram,
  sendAndConfirmTransaction,
  LAMPORTS_PER_SOL
} from '@solana/web3.js';
import * as bip39 from 'bip39';
import { derivePath } from 'ed25519-hd-key';
import { CryptoService, TransactionInfo, IncomingTransaction } from './CryptoService';

/**
 * Solana blockchain service
 * Supports SOL and SPL tokens
 */
export class SolanaService extends CryptoService {
  private connection: Connection;
  
  constructor(
    masterMnemonic: string,
    rpcEndpoint: string,
    masterWallet: string
  ) {
    super(masterMnemonic, rpcEndpoint, masterWallet);
    this.connection = new Connection(rpcEndpoint, 'confirmed');
  }
  
  /**
   * Get BIP44 derivation path for Solana
   * m/44'/501'/0'/0' for Solana (note: Solana uses hardened paths throughout)
   */
  protected getDerivationPath(index: number): string {
    return `m/44'/501'/${index}'/0'`;
  }
  
  /**
   * Generate Solana address for a user
   */
  async generateAddress(userIndex: number): Promise<string> {
    try {
      const seed = await bip39.mnemonicToSeed(this.masterMnemonic);
      const path = this.getDerivationPath(userIndex);
      
      // Solana uses ED25519 curve, not secp256k1
      const derivedSeed = derivePath(path, seed.toString('hex')).key;
      const keypair = Keypair.fromSeed(derivedSeed);
      
      return keypair.publicKey.toBase58();
    } catch (error) {
      throw new Error(`Failed to generate Solana address: ${error}`);
    }
  }
  
  /**
   * Derive private key for signing
   */
  protected async derivePrivateKey(userIndex: number): Promise<string> {
    try {
      const seed = await bip39.mnemonicToSeed(this.masterMnemonic);
      const path = this.getDerivationPath(userIndex);
      
      const derivedSeed = derivePath(path, seed.toString('hex')).key;
      const keypair = Keypair.fromSeed(derivedSeed);
      
      // Return as base58 encoded
      return Buffer.from(keypair.secretKey).toString('base64');
    } catch (error) {
      throw new Error(`Failed to derive private key: ${error}`);
    }
  }
  
  /**
   * Get SOL balance in lamports (1 SOL = 1,000,000,000 lamports)
   */
  async getBalance(address: string): Promise<bigint> {
    try {
      const publicKey = new PublicKey(address);
      const balance = await this.connection.getBalance(publicKey);
      return BigInt(balance);
    } catch (error) {
      throw new Error(`Failed to get SOL balance: ${error}`);
    }
  }
  
  /**
   * Get SPL token balance
   */
  async getTokenBalance(address: string, tokenContract?: string): Promise<bigint> {
    if (!tokenContract) {
      throw new Error('Token contract address required for Solana');
    }
    
    try {
      const publicKey = new PublicKey(address);
      const tokenPublicKey = new PublicKey(tokenContract);
      
      // Get token accounts for this wallet
      const tokenAccounts = await this.connection.getParsedTokenAccountsByOwner(
        publicKey,
        { mint: tokenPublicKey }
      );
      
      if (tokenAccounts.value.length === 0) {
        return 0n;
      }
      
      const balance = tokenAccounts.value[0].account.data.parsed.info.tokenAmount.amount;
      return BigInt(balance);
    } catch (error) {
      throw new Error(`Failed to get SPL token balance: ${error}`);
    }
  }
  
  /**
   * Estimate transaction cost (rent + fees)
   */
  async estimateGas(from: string, to: string, amount?: bigint, isToken: boolean = false): Promise<bigint> {
    try {
      // Solana has fixed transaction fees
      const recentBlockhash = await this.connection.getLatestBlockhash();
      
      // Base fee is ~5000 lamports
      let baseFee = 5000n;
      
      if (isToken) {
        // Token transfers may need to create associated token account
        // Add rent exemption amount (~0.002 SOL)
        baseFee += 2_000_000n;
      }
      
      return baseFee;
    } catch (error) {
      throw new Error(`Failed to estimate gas: ${error}`);
    }
  }
  
  /**
   * Sweep SOL to master wallet
   */
  async sweep(privateKey: string, destination: string, amount: bigint): Promise<string> {
    try {
      // Decode private key
      const secretKey = Buffer.from(privateKey, 'base64');
      const fromKeypair = Keypair.fromSecretKey(secretKey);
      const toPublicKey = new PublicKey(destination);
      
      // Create transfer transaction
      const transaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey: fromKeypair.publicKey,
          toPubkey: toPublicKey,
          lamports: Number(amount)
        })
      );
      
      // Send and confirm
      const signature = await sendAndConfirmTransaction(
        this.connection,
        transaction,
        [fromKeypair]
      );
      
      return signature;
    } catch (error) {
      throw new Error(`Failed to sweep SOL: ${error}`);
    }
  }
  
  /**
   * Sweep SPL token to master wallet
   */
  async sweepToken(privateKey: string, destination: string, amount: bigint, tokenContract: string): Promise<string> {
    try {
      // Note: Full SPL token implementation requires @solana/spl-token package
      // This is a simplified version
      throw new Error('SPL token sweeping not yet implemented - requires @solana/spl-token');
      
      // TODO: Implement using:
      // import { createTransferInstruction, getAssociatedTokenAddress } from '@solana/spl-token';
    } catch (error) {
      throw new Error(`Failed to sweep SPL token: ${error}`);
    }
  }
  
  /**
   * Fund SOL for token sweeping
   */
  async fundGas(hotWalletKey: string, destination: string, gasAmount: bigint): Promise<string> {
    try {
      const secretKey = Buffer.from(hotWalletKey, 'base64');
      const fromKeypair = Keypair.fromSecretKey(secretKey);
      const toPublicKey = new PublicKey(destination);
      
      const transaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey: fromKeypair.publicKey,
          toPubkey: toPublicKey,
          lamports: Number(gasAmount)
        })
      );
      
      const signature = await sendAndConfirmTransaction(
        this.connection,
        transaction,
        [fromKeypair]
      );
      
      return signature;
    } catch (error) {
      throw new Error(`Failed to fund gas: ${error}`);
    }
  }
  
  /**
   * Get current slot (Solana's equivalent of block number)
   */
  async getCurrentBlock(): Promise<number> {
    try {
      return await this.connection.getSlot();
    } catch (error) {
      throw new Error(`Failed to get current slot: ${error}`);
    }
  }
  
  /**
   * Get transaction details
   */
  async getTransaction(txHash: string): Promise<TransactionInfo> {
    try {
      const tx = await this.connection.getTransaction(txHash, {
        maxSupportedTransactionVersion: 0
      });
      
      if (!tx) {
        throw new Error('Transaction not found');
      }
      
      const currentSlot = await this.getCurrentBlock();
      const confirmations = tx.slot ? currentSlot - tx.slot : 0;
      
      // Parse transaction details
      const meta = tx.meta;
      const message = tx.transaction.message;
      
      // Get accounts involved
      const accountKeys = message.getAccountKeys();
      const from = accountKeys.get(0)?.toBase58() || '';
      const to = accountKeys.get(1)?.toBase58() || '';
      
      // Calculate value transferred
      let value = 0n;
      if (meta?.postBalances && meta?.preBalances) {
        value = BigInt(meta.postBalances[1] - meta.preBalances[1]);
      }
      
      return {
        hash: txHash,
        from,
        to,
        value,
        blockNumber: tx.slot,
        confirmations,
        timestamp: tx.blockTime || 0,
        status: meta?.err ? 'failed' : 'confirmed',
        gasUsed: BigInt(meta?.fee || 0)
      };
    } catch (error) {
      throw new Error(`Failed to get transaction: ${error}`);
    }
  }
  
  /**
   * Scan address for incoming transactions
   */
  async scanAddress(address: string, fromBlock: number): Promise<IncomingTransaction[]> {
    try {
      const publicKey = new PublicKey(address);
      const signatures = await this.connection.getSignaturesForAddress(publicKey, {
        limit: 100
      });
      
      const transactions: IncomingTransaction[] = [];
      
      for (const sig of signatures) {
        if (sig.slot >= fromBlock) {
          const tx = await this.getTransaction(sig.signature);
          
          if (tx.to === address) {
            transactions.push({
              hash: sig.signature,
              from: tx.from,
              to: tx.to,
              value: tx.value,
              blockNumber: sig.slot,
              timestamp: sig.blockTime || 0,
              isToken: false
            });
          }
        }
      }
      
      return transactions;
    } catch (error) {
      throw new Error(`Failed to scan address: ${error}`);
    }
  }
}
