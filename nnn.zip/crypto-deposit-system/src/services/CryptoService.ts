import { ethers } from 'ethers';

/**
 * Abstract base class for all cryptocurrency services
 * Defines the interface that all chain implementations must follow
 */
export abstract class CryptoService {
  protected masterMnemonic: string;
  protected rpcEndpoint: string;
  protected masterWallet: string;
  
  constructor(masterMnemonic: string, rpcEndpoint: string, masterWallet: string) {
    this.masterMnemonic = masterMnemonic;
    this.rpcEndpoint = rpcEndpoint;
    this.masterWallet = masterWallet;
  }
  
  /**
   * Generate a deposit address for a user
   * @param userIndex - The unique index for this user (from database)
   * @returns The generated address string
   */
  abstract generateAddress(userIndex: number): Promise<string>;
  
  /**
   * Get the balance of native coin at an address
   * @param address - The address to check
   * @returns Balance in the smallest unit (wei, lamports, etc.)
   */
  abstract getBalance(address: string): Promise<bigint>;
  
  /**
   * Get the balance of a token at an address
   * @param address - The address to check
   * @param tokenContract - The token contract address (if applicable)
   * @returns Token balance in the smallest unit
   */
  abstract getTokenBalance(address: string, tokenContract?: string): Promise<bigint>;
  
  /**
   * Estimate gas cost for a transaction
   * @param from - Source address
   * @param to - Destination address
   * @param amount - Amount to send (optional)
   * @param isToken - Whether this is a token transfer
   * @returns Estimated gas cost in native currency
   */
  abstract estimateGas(from: string, to: string, amount?: bigint, isToken?: boolean): Promise<bigint>;
  
  /**
   * Send native coin from one address to another
   * @param privateKey - Private key of the source address
   * @param destination - Destination address
   * @param amount - Amount to send in smallest unit
   * @returns Transaction hash
   */
  abstract sweep(privateKey: string, destination: string, amount: bigint): Promise<string>;
  
  /**
   * Send token from one address to another
   * @param privateKey - Private key of the source address
   * @param destination - Destination address
   * @param amount - Amount to send in smallest unit
   * @param tokenContract - Token contract address
   * @returns Transaction hash
   */
  abstract sweepToken(privateKey: string, destination: string, amount: bigint, tokenContract: string): Promise<string>;
  
  /**
   * Fund gas to an address (for token sweeps)
   * @param hotWalletKey - Private key of hot wallet
   * @param destination - Address to fund
   * @param gasAmount - Amount of native coin to send
   * @returns Transaction hash
   */
  abstract fundGas(hotWalletKey: string, destination: string, gasAmount: bigint): Promise<string>;
  
  /**
   * Get current block height
   * @returns Current block number
   */
  abstract getCurrentBlock(): Promise<number>;
  
  /**
   * Get transaction details
   * @param txHash - Transaction hash
   * @returns Transaction details including confirmations
   */
  abstract getTransaction(txHash: string): Promise<TransactionInfo>;
  
  /**
   * Monitor address for incoming transactions
   * @param address - Address to monitor
   * @param fromBlock - Block to start scanning from
   * @returns Array of detected transactions
   */
  abstract scanAddress(address: string, fromBlock: number): Promise<IncomingTransaction[]>;
  
  /**
   * Derive private key for a user index
   * @param userIndex - User's unique index
   * @returns Private key string (NEVER store this)
   */
  protected abstract derivePrivateKey(userIndex: number): Promise<string>;
  
  /**
   * Get the derivation path for this chain
   */
  protected abstract getDerivationPath(index: number): string;
}

/**
 * Transaction information interface
 */
export interface TransactionInfo {
  hash: string;
  from: string;
  to: string;
  value: bigint;
  blockNumber: number;
  confirmations: number;
  timestamp: number;
  status: 'pending' | 'confirmed' | 'failed';
  gasUsed?: bigint;
  tokenTransfers?: TokenTransfer[];
}

/**
 * Token transfer information
 */
export interface TokenTransfer {
  from: string;
  to: string;
  value: bigint;
  tokenAddress: string;
  tokenSymbol?: string;
  tokenDecimals?: number;
}

/**
 * Incoming transaction for monitoring
 */
export interface IncomingTransaction {
  hash: string;
  from: string;
  to: string;
  value: bigint;
  blockNumber: number;
  timestamp: number;
  isToken: boolean;
  tokenAddress?: string;
  tokenSymbol?: string;
  tokenAmount?: bigint;
}

/**
 * Helper function to convert between units
 */
export class CryptoUtils {
  static weiToEther(wei: bigint): string {
    return ethers.formatEther(wei);
  }
  
  static etherToWei(ether: string): bigint {
    return ethers.parseEther(ether);
  }
  
  static formatUnits(value: bigint, decimals: number): string {
    return ethers.formatUnits(value, decimals);
  }
  
  static parseUnits(value: string, decimals: number): bigint {
    return ethers.parseUnits(value, decimals);
  }
}
