// @ts-ignore - TronWeb doesn't have TypeScript definitions
import TronWeb from 'tronweb';
import * as bip39 from 'bip39';
import { BIP32Factory } from 'bip32';
import * as ecc from 'tiny-secp256k1';
import { CryptoService, TransactionInfo, IncomingTransaction } from './CryptoService';

const bip32 = BIP32Factory(ecc);

/**
 * TRON blockchain service
 * Supports TRX and TRC20 tokens (including USDT)
 */
export class TronService extends CryptoService {
  private tronWeb: TronWeb;
  private readonly USDT_TRC20_CONTRACT = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
  
  constructor(
    masterMnemonic: string,
    rpcEndpoint: string,
    masterWallet: string
  ) {
    super(masterMnemonic, rpcEndpoint, masterWallet);
    
    this.tronWeb = new TronWeb({
      fullHost: rpcEndpoint,
      headers: { 'TRON-PRO-API-KEY': process.env.TRONSCAN_API_KEY || '' }
    });
  }
  
  /**
   * Get BIP44 derivation path for TRON
   * m/44'/195'/0'/0/{index}
   */
  protected getDerivationPath(index: number): string {
    return `m/44'/195'/0'/0/${index}`;
  }
  
  /**
   * Generate TRON address for a user
   */
  async generateAddress(userIndex: number): Promise<string> {
    try {
      const seed = await bip39.mnemonicToSeed(this.masterMnemonic);
      const root = bip32.fromSeed(seed);
      const path = this.getDerivationPath(userIndex);
      const child = root.derivePath(path);
      
      if (!child.privateKey) {
        throw new Error('Failed to derive private key');
      }
      
      // Convert private key to TRON address
      const privateKeyHex = child.privateKey.toString('hex');
      const address = this.tronWeb.address.fromPrivateKey(privateKeyHex);
      
      return address;
    } catch (error) {
      throw new Error(`Failed to generate TRON address: ${error}`);
    }
  }
  
  /**
   * Derive private key for signing
   */
  protected async derivePrivateKey(userIndex: number): Promise<string> {
    try {
      const seed = await bip39.mnemonicToSeed(this.masterMnemonic);
      const root = bip32.fromSeed(seed);
      const path = this.getDerivationPath(userIndex);
      const child = root.derivePath(path);
      
      if (!child.privateKey) {
        throw new Error('Failed to derive private key');
      }
      
      return child.privateKey.toString('hex');
    } catch (error) {
      throw new Error(`Failed to derive private key: ${error}`);
    }
  }
  
  /**
   * Get TRX balance in sun (1 TRX = 1,000,000 sun)
   */
  async getBalance(address: string): Promise<bigint> {
    try {
      const balance = await this.tronWeb.trx.getBalance(address);
      return BigInt(balance);
    } catch (error) {
      throw new Error(`Failed to get TRX balance: ${error}`);
    }
  }
  
  /**
   * Get TRC20 token balance
   */
  async getTokenBalance(address: string, tokenContract?: string): Promise<bigint> {
    if (!tokenContract) {
      tokenContract = this.USDT_TRC20_CONTRACT;
    }
    
    try {
      const contract = await this.tronWeb.contract().at(tokenContract);
      const balance = await contract.balanceOf(address).call();
      return BigInt(balance.toString());
    } catch (error) {
      throw new Error(`Failed to get TRC20 token balance: ${error}`);
    }
  }
  
  /**
   * Estimate bandwidth and energy costs
   */
  async estimateGas(from: string, to: string, amount?: bigint, isToken: boolean = false): Promise<bigint> {
    try {
      // TRON uses bandwidth and energy, not gas
      // For simplicity, we'll return the minimum TRX needed (~10 TRX for tokens, ~1 TRX for native)
      if (isToken) {
        return BigInt(10_000_000); // 10 TRX in sun
      } else {
        return BigInt(1_000_000); // 1 TRX in sun
      }
    } catch (error) {
      throw new Error(`Failed to estimate gas: ${error}`);
    }
  }
  
  /**
   * Sweep TRX to master wallet
   */
  async sweep(privateKey: string, destination: string, amount: bigint): Promise<string> {
    try {
      // Create temporary TronWeb instance with private key
      const tempTronWeb = new TronWeb({
        fullHost: this.tronWeb.fullHost,
        privateKey
      });
      
      const transaction = await tempTronWeb.transactionBuilder.sendTrx(
        destination,
        Number(amount),
        tempTronWeb.defaultAddress.base58
      );
      
      const signedTx = await tempTronWeb.trx.sign(transaction);
      const txResult = await tempTronWeb.trx.sendRawTransaction(signedTx);
      
      if (!txResult.result) {
        throw new Error(txResult.message || 'Transaction failed');
      }
      
      return txResult.txid;
    } catch (error) {
      throw new Error(`Failed to sweep TRX: ${error}`);
    }
  }
  
  /**
   * Sweep TRC20 token to master wallet
   */
  async sweepToken(privateKey: string, destination: string, amount: bigint, tokenContract: string): Promise<string> {
    try {
      const tempTronWeb = new TronWeb({
        fullHost: this.tronWeb.fullHost,
        privateKey
      });
      
      const contract = await tempTronWeb.contract().at(tokenContract);
      
      // Call the transfer function
      const result = await contract.transfer(
        destination,
        amount.toString()
      ).send({
        feeLimit: 100_000_000 // 100 TRX fee limit
      });
      
      return result;
    } catch (error) {
      throw new Error(`Failed to sweep TRC20 token: ${error}`);
    }
  }
  
  /**
   * Fund TRX for token sweeping
   */
  async fundGas(hotWalletKey: string, destination: string, gasAmount: bigint): Promise<string> {
    try {
      const tempTronWeb = new TronWeb({
        fullHost: this.tronWeb.fullHost,
        privateKey: hotWalletKey
      });
      
      const transaction = await tempTronWeb.transactionBuilder.sendTrx(
        destination,
        Number(gasAmount),
        tempTronWeb.defaultAddress.base58
      );
      
      const signedTx = await tempTronWeb.trx.sign(transaction);
      const txResult = await tempTronWeb.trx.sendRawTransaction(signedTx);
      
      if (!txResult.result) {
        throw new Error(txResult.message || 'Gas funding failed');
      }
      
      return txResult.txid;
    } catch (error) {
      throw new Error(`Failed to fund gas: ${error}`);
    }
  }
  
  /**
   * Get current block number
   */
  async getCurrentBlock(): Promise<number> {
    try {
      const block = await this.tronWeb.trx.getCurrentBlock();
      return block.block_header.raw_data.number;
    } catch (error) {
      throw new Error(`Failed to get current block: ${error}`);
    }
  }
  
  /**
   * Get transaction details
   */
  async getTransaction(txHash: string): Promise<TransactionInfo> {
    try {
      const tx = await this.tronWeb.trx.getTransaction(txHash);
      const txInfo = await this.tronWeb.trx.getTransactionInfo(txHash);
      
      const currentBlock = await this.getCurrentBlock();
      const confirmations = txInfo.blockNumber 
        ? currentBlock - txInfo.blockNumber + 1 
        : 0;
      
      const value = tx.raw_data?.contract?.[0]?.parameter?.value?.amount || 0;
      
      return {
        hash: txHash,
        from: this.tronWeb.address.fromHex(tx.raw_data.contract[0].parameter.value.owner_address),
        to: this.tronWeb.address.fromHex(tx.raw_data.contract[0].parameter.value.to_address || 
                                         tx.raw_data.contract[0].parameter.value.contract_address),
        value: BigInt(value),
        blockNumber: txInfo.blockNumber || 0,
        confirmations,
        timestamp: txInfo.blockTimeStamp || 0,
        status: txInfo.receipt?.result === 'SUCCESS' ? 'confirmed' : 'failed',
        gasUsed: BigInt(txInfo.receipt?.energy_usage_total || 0)
      };
    } catch (error) {
      throw new Error(`Failed to get transaction: ${error}`);
    }
  }
  
  /**
   * Scan address for incoming transactions
   */
  async scanAddress(address: string, fromBlock: number): Promise<IncomingTransaction[]> {
    try {
      // Note: This requires TronGrid API or similar service
      // Simplified implementation - in production use TronGrid events API
      const transactions: IncomingTransaction[] = [];
      
      // Get recent transactions for address
      const txList = await this.tronWeb.trx.getTransactionsRelated(address, 'to');
      
      for (const tx of txList) {
        if (tx.blockNumber && tx.blockNumber >= fromBlock) {
          const value = tx.raw_data?.contract?.[0]?.parameter?.value?.amount || 0;
          
          transactions.push({
            hash: tx.txID,
            from: this.tronWeb.address.fromHex(tx.raw_data.contract[0].parameter.value.owner_address),
            to: address,
            value: BigInt(value),
            blockNumber: tx.blockNumber,
            timestamp: tx.block_timestamp || 0,
            isToken: tx.raw_data.contract[0].type === 'TriggerSmartContract'
          });
        }
      }
      
      return transactions;
    } catch (error) {
      throw new Error(`Failed to scan address: ${error}`);
    }
  }
}
