# 🚀 Quick Start - No .env File Needed!

## ✅ Everything is Configured Directly in bot.py

You no longer need any .env file! All configuration is done directly at the top of `bot.py`.

## 📝 How to Configure

### Step 1: Open bot.py

Open `bot.py` in any text editor and scroll to lines 95-165.

### Step 2: Fill in Your Values

Look for this section near the top of the file:

```python
# ========================================
# 🔐 SECURITY CRITICAL - FILL THESE VALUES
# ========================================
MASTER_MNEMONIC = ""  # Add your 24-word seed phrase here
HOT_WALLET_PRIVATE_KEY = ""  # Add your hot wallet private key
MASTER_WALLETS = {
    "ETH": "",      # Add your Ethereum address
    "BNB": "",      # Add your BNB Chain address
    "BASE": "",     # Add your Base address
    "TRON": "",     # Add your TRON address
    "SOLANA": "",   # Add your Solana address
    "TON": ""       # Add your TON address
}
```

### Step 3: Run the Bot

```bash
python3 bot.py
```

That's it! No .env file, no external configuration needed.

## 🔐 Security Notes

### Master Mnemonic
- Generate a secure 24-word mnemonic at: https://iancoleman.io/bip39/
- ⚠️ **KEEP THIS SECRET!** Anyone with this can access ALL deposit addresses
- This single seed generates unique addresses for every user

### Hot Wallet
- Used only for funding gas when users deposit tokens
- Keep minimal balance (max $50-100)
- Format: `0x1234567890abcdef...` (64 characters)

### Master Wallets
- These are where ALL deposits are swept to
- Use cold wallets or hardware wallets
- **ETH/BNB/BASE**: Same format `0x...` (42 characters)
- **TRON**: Format `T...` (34 characters)
- **SOLANA**: Format base58 (32-44 characters)
- **TON**: Format `EQ...` or `UQ...`

## 📖 Example Configuration

```python
MASTER_MNEMONIC = "word1 word2 word3 word4 word5 word6 word7 word8 word9 word10 word11 word12 word13 word14 word15 word16 word17 word18 word19 word20 word21 word22 word23 word24"

HOT_WALLET_PRIVATE_KEY = "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"

MASTER_WALLETS = {
    "ETH": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
    "BNB": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
    "BASE": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
    "TRON": "TAbCdEfGhIjKlMnOpQrStUvWxYz1234567",
    "SOLANA": "7EcDhSYGxXyscszYEp35KHN8vvw3svAuLKTzXwCFLtV",
    "TON": "EQAbCdEfGhIjKlMnOpQrStUvWxYz1234567890"
}
```

## ⚙️ Optional Settings

You can also customize these settings in bot.py if needed:

```python
MIN_DEPOSIT_USD = 10.0       # Minimum deposit amount
SCAN_INTERVAL = 30            # Scan blockchain every 30 seconds
SWEEP_INTERVAL = 60           # Sweep deposits every 60 seconds
```

## 🌐 RPC Endpoints

Default public RPCs are provided. You can optionally use your own:

```python
RPC_ENDPOINTS = {
    "ETH": "https://eth.llamarpc.com",  # Or your Alchemy/Infura URL
    "BNB": "https://bsc-dataseed.binance.org/",
    # ... etc
}
```

## ✨ That's It!

No .env file needed. Just edit bot.py at the top and run it!
