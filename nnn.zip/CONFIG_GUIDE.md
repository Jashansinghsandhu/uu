# 🎯 CONFIGURATION GUIDE - Single File Solution

## ✅ No .env File Required!

Everything is configured directly in `bot.py`. No external files needed.

## 📝 Configuration Location

**File**: `bot.py`  
**Lines**: 95-165

## 🔧 What You Need to Fill In

### 1. Master Mnemonic (Line 107)

```python
MASTER_MNEMONIC = ""  # Put your 24-word seed phrase here
```

**What is this?**
- A 24-word BIP39 seed phrase
- Generates ALL user deposit addresses
- **EXTREMELY IMPORTANT**: Keep this secret!

**How to generate:**
1. Visit: https://iancoleman.io/bip39/
2. Select "24 words"
3. Click "Generate"
4. Copy the mnemonic

**Example:**
```python
MASTER_MNEMONIC = "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about"
```

### 2. Hot Wallet Private Key (Line 111)

```python
HOT_WALLET_PRIVATE_KEY = ""  # Put your private key here
```

**What is this?**
- Ethereum private key (works for all EVM chains)
- Used ONLY for funding gas when users deposit tokens
- Keep minimal balance ($50-100 max)

**Format:**
- Must start with `0x`
- 66 characters total (0x + 64 hex characters)

**How to generate:**
```python
# Using web3.py
from eth_account import Account
import secrets
priv = secrets.token_hex(32)
account = Account.from_key(priv)
print(f"Private Key: 0x{priv}")
print(f"Address: {account.address}")
```

**Example:**
```python
HOT_WALLET_PRIVATE_KEY = "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
```

### 3. Master Wallets (Lines 115-122)

```python
MASTER_WALLETS = {
    "ETH": "",      # Ethereum address
    "BNB": "",      # BNB Chain address
    "BASE": "",     # Base address
    "TRON": "",     # TRON address
    "SOLANA": "",   # Solana address
    "TON": ""       # TON address
}
```

**What is this?**
- Addresses where ALL deposits are swept to
- Use cold storage or hardware wallets
- One address per blockchain

**Formats:**
- **ETH/BNB/BASE**: `0x...` (42 characters)
- **TRON**: `T...` (34 characters)
- **SOLANA**: base58 string (32-44 characters)
- **TON**: `EQ...` or `UQ...` format

**Example:**
```python
MASTER_WALLETS = {
    "ETH": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
    "BNB": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
    "BASE": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
    "TRON": "TAbCdEfGhIjKlMnOpQrStUvWxYz1234567",
    "SOLANA": "7EcDhSYGxXyscszYEp35KHN8vvw3svAuLKTzXwCFLtV",
    "TON": "EQAbCdEfGhIjKlMnOpQrStUvWxYz1234567890"
}
```

## ⚙️ Optional Settings (Lines 162-164)

These have sensible defaults, but you can customize:

```python
MIN_DEPOSIT_USD = 10.0       # Minimum deposit amount
SCAN_INTERVAL = 30            # Scan blockchains every X seconds
SWEEP_INTERVAL = 60           # Sweep deposits every X seconds
```

## 🌐 RPC Endpoints (Lines 128-135)

Default public RPCs are provided. You can use your own:

```python
RPC_ENDPOINTS = {
    "ETH": "https://eth.llamarpc.com",
    "BNB": "https://bsc-dataseed.binance.org/",
    "BASE": "https://mainnet.base.org",
    "TRON": "https://api.trongrid.io",
    "SOLANA": "https://api.mainnet-beta.solana.com",
    "TON": "https://toncenter.com/api/v2/jsonRPC"
}
```

**Optional upgrades:**
- **Ethereum**: Use Alchemy or Infura
- **BNB**: Use NodeReal
- **Solana**: Use Helius
- Others: Keep defaults

## 📋 Complete Example

Here's a complete configuration example:

```python
# ===== DEPOSIT SYSTEM CONFIGURATION =====
DEPOSIT_ENABLED = True
DEPOSITS_DB = "deposits.db"

# ========================================
# 🔐 SECURITY CRITICAL - FILL THESE VALUES
# ========================================
MASTER_MNEMONIC = "word1 word2 word3 word4 word5 word6 word7 word8 word9 word10 word11 word12 word13 word14 word15 word16 word17 word18 word19 word20 word21 word22 word23 word24"

HOT_WALLET_PRIVATE_KEY = "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"

MASTER_WALLETS = {
    "ETH": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
    "BNB": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
    "BASE": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
    "TRON": "TAbCdEfGhIjKlMnOpQrStUvWxYz1234567",
    "SOLANA": "7EcDhSYGxXyscszYEp35KHN8vvw3svAuLKTzXwCFLtV",
    "TON": "EQAbCdEfGhIjKlMnOpQrStUvWxYz1234567890"
}

# ========================================
# 🌐 BLOCKCHAIN RPC ENDPOINTS (Optional)
# ========================================
RPC_ENDPOINTS = {
    "ETH": "https://eth.llamarpc.com",
    "BNB": "https://bsc-dataseed.binance.org/",
    "BASE": "https://mainnet.base.org",
    "TRON": "https://api.trongrid.io",
    "SOLANA": "https://api.mainnet-beta.solana.com",
    "TON": "https://toncenter.com/api/v2/jsonRPC"
}

# ========================================
# ⚙️ DEPOSIT SETTINGS (Optional)
# ========================================
MIN_DEPOSIT_USD = 10.0
SCAN_INTERVAL = 30
SWEEP_INTERVAL = 60
```

## 🔒 Security Checklist

Before running in production:

- [ ] Generated secure 24-word mnemonic
- [ ] Backed up mnemonic in safe place (offline)
- [ ] Created hot wallet with minimal balance
- [ ] Set up master wallets with cold storage
- [ ] Tested on testnet first
- [ ] Never shared mnemonic with anyone
- [ ] bot.py is not committed to public repo with real values

## 🚀 Quick Start Steps

1. **Open bot.py** in text editor
2. **Go to lines 95-165**
3. **Fill in the three required values:**
   - MASTER_MNEMONIC (line 107)
   - HOT_WALLET_PRIVATE_KEY (line 111)
   - MASTER_WALLETS dictionary (lines 115-122)
4. **Save the file**
5. **Run:** `python3 bot.py`

## ❓ FAQ

**Q: Do I need all 6 master wallet addresses?**  
A: No, only fill in the ones you want to support. Leave others empty.

**Q: Can I use the same address for ETH, BNB, and BASE?**  
A: Yes! They're all EVM-compatible, so same address works.

**Q: How much should I fund the hot wallet?**  
A: Just enough for gas. $50-100 is plenty. It auto-funds user addresses as needed.

**Q: What if I lose the master mnemonic?**  
A: All deposit addresses become inaccessible! Back it up securely offline.

**Q: Can I change these values later?**  
A: Hot wallet and master wallets can be changed. Master mnemonic should NOT be changed (all existing addresses depend on it).

## 📞 Need Help?

Check these files:
- **NO_ENV_NEEDED.md** - What changed
- **SIMPLE_SETUP.md** - Quick start
- **bot.py lines 95-165** - Configuration section

---

**Remember**: Everything is in bot.py. No .env file needed!
